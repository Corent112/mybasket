import { Document, Page, Text, View, Image, StyleSheet } from "@react-pdf/renderer";
import { cleanPracticeText, parsePracticeDuration, shortCoachCode } from "@/lib/practice-session-format";

type CompositionTeam = { id?: string; name: string; playerIds: string[] };
type CompositionBlock = {
  id?: string;
  title: string;
  playersPerTeam?: number;
  teams: CompositionTeam[];
};

type Session = {
  title: string;
  theme: string | null;
  session_date: string | null;
  start_time: string | null;
  end_time: string | null;
  location: string | null;
  club_logo_url: string | null;
  mybasket_logo_url: string | null;
  team_composition_blocks?: CompositionBlock[] | string | null;
  player_groups?: Record<string, string[]> | string | null;
  notes?: string | Record<string, unknown> | null;
};

type Player = {
  id?: string | null;
  player_id?: string | null;
  first_name: string | null;
  last_name: string | null;
  position: "guard" | "forward" | "center" | null;
};

type Exercise = {
  title: string;
  who: string | null;
  duration_minutes: number | null;
  situation_image_url?: string | null;
  schema_urls?: string[] | null;
  explanation: string | null;
  instructions: string | null;
  variants?: string | null;
};

type Props = {
  session: Session;
  players: Player[];
  exercises: Exercise[];
};

function formatDate(date?: string | null) {
  if (!date) return "—";
  return new Date(date).toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

function formatTime(time?: string | null) {
  return time ? time.slice(0, 5) : "";
}

function playerName(player: Player) {
  return `${player.first_name ?? ""} ${player.last_name ?? ""}`.trim() || "Joueur";
}

function playerId(player: Player) {
  return String(player.player_id || player.id || "");
}

function compositionBlocks(session: Session): CompositionBlock[] {
  const normalizeBlocks = (raw: unknown): CompositionBlock[] => {
    let value = raw;

    if (typeof value === "string") {
      try {
        value = JSON.parse(value);
      } catch {
        return [];
      }
    }

    if (!Array.isArray(value)) return [];

    return (value as CompositionBlock[])
      .map((block) => ({
        ...block,
        title: String(block?.title || "Composition"),
        teams: Array.isArray(block?.teams)
          ? block.teams
              .map((team) => ({
                ...team,
                name: String(team?.name || "Équipe"),
                playerIds: Array.isArray(team?.playerIds)
                  ? team.playerIds.map(String).filter(Boolean)
                  : [],
              }))
              .filter((team) => team.playerIds.length > 0)
          : [],
      }))
      .filter((block) => block.teams.length > 0);
  };

  // 1. Source normale : colonne JSONB practice_sessions.team_composition_blocks.
  const direct = normalizeBlocks(session.team_composition_blocks);
  if (direct.length > 0) return direct;

  // 2. Snapshot de secours enregistré dans practice_sessions.notes.
  let notes: unknown = session.notes;
  if (typeof notes === "string") {
    try {
      notes = JSON.parse(notes);
    } catch {
      notes = null;
    }
  }

  if (notes && typeof notes === "object" && !Array.isArray(notes)) {
    const fromNotes = normalizeBlocks(
      (notes as Record<string, unknown>).team_composition_blocks,
    );
    if (fromNotes.length > 0) return fromNotes;
  }

  // 3. Compatibilité avec l'ancien player_groups.
  let legacyGroups: unknown = session.player_groups;

  if (typeof legacyGroups === "string") {
    try {
      legacyGroups = JSON.parse(legacyGroups);
    } catch {
      legacyGroups = {};
    }
  }

  if (
    legacyGroups &&
    typeof legacyGroups === "object" &&
    !Array.isArray(legacyGroups)
  ) {
    const teams = Object.entries(
      legacyGroups as Record<string, unknown>,
    ).map(([name, ids]) => ({
      name,
      playerIds: Array.isArray(ids) ? ids.map(String).filter(Boolean) : [],
    }));

    return normalizeBlocks([
      {
        title: "Équipes de travail",
        playersPerTeam: 0,
        teams,
      },
    ]);
  }

  return [];
}

export default function PracticeSessionPdf({ session, players, exercises }: Props) {
  const guards = players.filter((player) => player.position === "guard");
  const forwards = players.filter((player) => player.position === "forward");
  const centers = players.filter((player) => player.position === "center");
  const blocks = compositionBlocks(session);
  const totalDuration = exercises.reduce(
    (total, exercise) => total + parsePracticeDuration(exercise.duration_minutes, 0),
    0,
  );

  return (
    <Document>
      <Page size="A4" orientation="portrait" style={styles.page}>
        <View style={styles.header} wrap={false}>
          <View style={styles.logoBox}>
            {session.mybasket_logo_url ? (
              <Image src={session.mybasket_logo_url} style={styles.logo} />
            ) : (
              <Text style={styles.logoFallback}>MYBASKET</Text>
            )}
          </View>

          <View style={styles.headerCenter}>
            <Text style={styles.practicePlan}>Practice Plan</Text>
            <Text style={styles.headerMetaLine}>
              Date : {formatDate(session.session_date)}   •   Horaire : {formatTime(session.start_time)} - {formatTime(session.end_time)}   •   Équipe : {session.title || "—"}
            </Text>
            <Text style={styles.headerLine}>Thème : {session.theme || "—"}</Text>
          </View>

          <View style={styles.logoBox}>
            {session.club_logo_url ? (
              <Image src={session.club_logo_url} style={styles.logo} />
            ) : (
              <Text style={styles.logoFallback}>LOGO CLUB</Text>
            )}
          </View>
        </View>

        <View style={styles.playersTable} wrap={false}>
          <PlayerColumn title="Guard" players={guards} />
          <PlayerColumn title="Forward" players={forwards} />
          <PlayerColumn title="Center" players={centers} isLast />
        </View>

        <View style={styles.tableHeader} fixed>
          <Text style={styles.whoCell}>Qui</Text>
          <Text style={styles.timeCell}>Tps</Text>
          <Text style={styles.schemaCell}>Schémas</Text>
          <Text style={styles.explanationCell}>Déroulement</Text>
          <Text style={styles.instructionsCell}>Consignes / Variantes</Text>
        </View>

        {exercises.map((exercise, index) => {
          const images = Array.from(
            new Set([
              ...(Array.isArray(exercise.schema_urls) ? exercise.schema_urls : []),
              ...(exercise.situation_image_url ? [exercise.situation_image_url] : []),
            ].filter(Boolean)),
          ) as string[];

          return (
            <View key={`${exercise.title}-${index}`} style={styles.exerciseRow} wrap={false}>
              <View style={styles.whoCellBody}>
                <Text>{shortCoachCode(exercise.who)}</Text>
              </View>
              <View style={styles.timeCellBody}>
                <Text>{parsePracticeDuration(exercise.duration_minutes, 0)}'</Text>
              </View>
              <View style={styles.schemaCellBody}>
                <Text style={styles.exerciseTitle}>{exercise.title || `Exercice ${index + 1}`}</Text>
                {images.length ? (
                  <View style={styles.imageGrid}>
                    {images.map((image, imageIndex) => (
                      <Image
                        key={`${image}-${imageIndex}`}
                        src={image}
                        style={
                          images.length === 1
                            ? styles.singleImage
                            : images.length === 2
                              ? styles.doubleImage
                              : styles.multiImage
                        }
                      />
                    ))}
                  </View>
                ) : (
                  <View style={styles.noSchema}>
                    <Text>Aucun schéma</Text>
                  </View>
                )}
              </View>
              <View style={styles.explanationCellBody}>
                <Text>{cleanPracticeText(exercise.explanation) || "—"}</Text>
              </View>
              <View style={styles.instructionsCellBody}>
                <Text>
                  {cleanPracticeText(exercise.instructions) ||
                    cleanPracticeText(exercise.variants) ||
                    "—"}
                </Text>
              </View>
            </View>
          );
        })}

        {blocks.length > 0 && (
          <View style={styles.compositionsSection}>
            <Text style={styles.compositionsTitle}>COMPOSITIONS D’ÉQUIPES</Text>
            {blocks.map((block, blockIndex) => (
              <View
                key={block.id || `${block.title}-${blockIndex}`}
                style={styles.blockCard}
              >
                <Text style={styles.blockTitle}>{block.title || `Bloc ${blockIndex + 1}`}</Text>
                <View style={styles.teamsGrid}>
                  {(block.teams || []).map((team, teamIndex) => {
                    const teamPlayers = (team.playerIds || [])
                      .map((id) => players.find((player) => playerId(player) === String(id)))
                      .filter((player): player is Player => Boolean(player));

                    return (
                      <View key={team.id || `${team.name}-${teamIndex}`} style={styles.teamCard}>
                        <Text style={styles.teamTitle}>{team.name || `Équipe ${teamIndex + 1}`}</Text>
                        {teamPlayers.map((player) => (
                          <Text key={playerId(player)} style={styles.teamPlayer}>
                            {playerName(player)}
                          </Text>
                        ))}
                      </View>
                    );
                  })}
                </View>
              </View>
            ))}
          </View>
        )}
      </Page>
    </Document>
  );
}

function PlayerColumn({
  title,
  players,
  isLast = false,
}: {
  title: string;
  players: Player[];
  isLast?: boolean;
}) {
  return (
    <View style={[styles.playerColumn, isLast ? styles.playerColumnLast : {}]}>
      <Text style={styles.playerColumnTitle}>{title}</Text>
      <View style={styles.playerList}>
        {players.length ? (
          players.map((player) => (
            <Text
              key={playerId(player)}
              style={[
                styles.playerName,
                players.length >= 10
                  ? styles.playerNameVeryCompact
                  : players.length >= 7
                    ? styles.playerNameCompact
                    : {},
              ]}
            >
              {playerName(player)}
            </Text>
          ))
        ) : (
          <Text style={styles.playerName}>—</Text>
        )}
      </View>
    </View>
  );
}

const borderColor = "#111111";

const styles = StyleSheet.create({
  page: {
    padding: 8,
    paddingBottom: 16,
    fontSize: 8,
    color: "#111111",
    backgroundColor: "#ffffff",
  },
  header: {
    minHeight: 76,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 5,
  },
  logoBox: {
    width: 105,
    minHeight: 92,
    alignItems: "center",
    justifyContent: "center",
  },
  logo: {
    width: 88,
    height: 88,
    objectFit: "contain",
  },
  logoFallback: {
    fontSize: 12,
    fontWeight: 900,
  },
  headerCenter: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 8,
  },
  practicePlan: {
  fontSize: 17,
  fontWeight: 900,
  textTransform: "uppercase",
  marginBottom: 3,
},

headerMetaLine: {
  fontSize: 8,
  fontWeight: 700,
  marginBottom: 1,
  textAlign: "center",
},
  headerLine: {
    fontSize: 9,
    fontWeight: 700,
    marginBottom: 1,
  },
  playersTable: {
    flexDirection: "row",
    borderWidth: 0.8,
    borderColor,
    marginBottom: 8,
  },
  playerColumn: {
    flex: 1,
    minHeight: 44,
    borderRightWidth: 0.8,
    borderRightColor: borderColor,
  },
  playerColumnLast: {
    borderRightWidth: 0,
  },
  playerColumnTitle: {
    paddingVertical: 2,
    textAlign: "center",
    fontSize: 9,
    fontWeight: 900,
    backgroundColor: "#d9d9d9",
    borderBottomWidth: 0.8,
    borderBottomColor: borderColor,
  },
  playerList: {
    paddingVertical: 2.5,
    paddingHorizontal: 4,
    alignItems: "center",
  },
  playerName: {
    fontSize: 7,
    fontWeight: 700,
    marginBottom: 0.5,
  },
  playerNameCompact: {
    fontSize: 6.2,
    marginBottom: 0.25,
  },
  playerNameVeryCompact: {
    fontSize: 5.4,
    marginBottom: 0.1,
  },
  tableHeader: {
    flexDirection: "row",
    minHeight: 34,
    alignItems: "stretch",
    backgroundColor: "#050505",
    color: "#ffffff",
    borderWidth: 0.8,
    borderColor,
  },
  whoCell: { width: 30, padding: 3, textAlign: "center", fontWeight: 900 },
  timeCell: { width: 32, padding: 3, textAlign: "center", fontWeight: 900, borderLeftWidth: 0.8, borderLeftColor: "#ffffff" },
  schemaCell: { width: 235, padding: 3, textAlign: "center", fontWeight: 900, borderLeftWidth: 0.8, borderLeftColor: "#ffffff" },
  explanationCell: { width: 135, padding: 4, textAlign: "center", fontWeight: 900, borderLeftWidth: 0.8, borderLeftColor: "#ffffff" },
  instructionsCell: { flex: 1, padding: 4, textAlign: "center", fontWeight: 900, borderLeftWidth: 0.8, borderLeftColor: "#ffffff" },
  exerciseRow: {
    minHeight: 88,
    flexDirection: "row",
    borderLeftWidth: 0.8,
    borderRightWidth: 0.8,
    borderBottomWidth: 0.8,
    borderColor,
  },
  whoCellBody: {
    width: 30,
    alignItems: "center",
    justifyContent: "center",
    padding: 3,
    borderRightWidth: 0.8,
    borderRightColor: borderColor,
    fontSize: 9,
    fontWeight: 900,
    textAlign: "center",
  },
  timeCellBody: {
    width: 32,
    alignItems: "center",
    justifyContent: "center",
    padding: 3,
    borderRightWidth: 0.8,
    borderRightColor: borderColor,
    fontSize: 9,
    fontWeight: 900,
  },
  schemaCellBody: {
    width: 235,
    padding: 4,
    borderRightWidth: 0.8,
    borderRightColor: borderColor,
  },
  explanationCellBody: {
    width: 135,
    alignItems: "center",
    justifyContent: "center",
    padding: 4,
    borderRightWidth: 0.8,
    borderRightColor: borderColor,
    lineHeight: 1.35,
    textAlign: "center",
    fontSize: 8.5,
    fontWeight: 700,
  },
  instructionsCellBody: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 4,
    lineHeight: 1.35,
    textAlign: "center",
    fontSize: 8.5,
    fontWeight: 700,
  },
  exerciseTitle: {
    marginBottom: 2,
    fontSize: 8.5,
    fontWeight: 900,
    textAlign: "center",
  },
  imageGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    alignItems: "center",
    gap: 3,
  },
  singleImage: {
    width: 208,
    height: 80,
    objectFit: "contain",
  },
  doubleImage: {
    width: 105,
    height: 76,
    objectFit: "contain",
    margin: 2,
  },
  multiImage: {
    width: 68,
    height: 70,
    objectFit: "contain",
  },
  noSchema: {
    minHeight: 58,
    alignItems: "center",
    justifyContent: "center",
    borderWidth: 0.5,
    borderColor: "#cccccc",
  },
  compositionsSection: {
    marginTop: 14,
  },
  compositionsTitle: {
    paddingVertical: 6,
    textAlign: "center",
    fontSize: 13,
    fontWeight: 900,
    color: "#6b1a2c",
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: "#6b1a2c",
    marginBottom: 8,
  },
  blockCard: {
    marginBottom: 10,
    padding: 7,
    borderWidth: 0.8,
    borderColor: "#d9c7bd",
    borderRadius: 5,
  },
  blockTitle: {
    marginBottom: 6,
    fontSize: 11,
    fontWeight: 900,
    color: "#6b1a2c",
    textAlign: "center",
  },
  teamsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    gap: 6,
  },
  teamCard: {
    width: "31.8%",
    minHeight: 62,
    padding: 5,
    borderWidth: 0.7,
    borderColor: "#bfa99d",
    borderRadius: 4,
  },
  teamTitle: {
    paddingBottom: 3,
    marginBottom: 3,
    borderBottomWidth: 0.6,
    borderBottomColor: "#d8c7be",
    fontSize: 9,
    fontWeight: 900,
  },
  teamPlayer: {
    fontSize: 7.5,
    marginBottom: 1.5,
  },
  emptyTeam: {
    fontSize: 7.5,
    color: "#888888",
  },
});
