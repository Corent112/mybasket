"use client";

import { useEffect, useMemo, useState } from "react";
import { createClient } from "@/lib/supabase/client";

type PlanningBlock = {
  id: string;
  cohort_id: string;
  training_day: string;
  start_time: string;
  end_time: string;
  title: string;
  formation_name: string | null;
  instructor_name: string | null;
  room_name: string | null;
  location_type: string | null;
  block_type: string;
  description: string | null;
  pedagogical_scenario_id: string | null;
};

type Scenario = {
  id: string;
  cohort_id: string;
  title: string;
  module_name: string | null;
  theme: string | null;
  total_duration_minutes: number;
  pedagogical_objectives: string | null;
};

type Asset = {
  id: string;
  block_id: string;
  title: string;
  asset_type: string;
  file_url: string;
  original_filename: string | null;
};

const BLOCK_TYPES = [
  ["training", "Intervention"],
  ["court", "Terrain"],
  ["meeting", "Réunion"],
  ["meal", "Déjeuner"],
  ["assessment", "Évaluation"],
  ["break", "Pause"],
  ["other", "Autre"],
];

function timeToMinutes(value: string) {
  const [h, m] = value.split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
}

function formatDay(value: string) {
  return new Date(`${value}T12:00:00`).toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
  });
}

export default function TrainingPlanningBoard({ cohortId }: { cohortId: string }) {
  const supabase = useMemo(() => createClient(), []);
  const [blocks, setBlocks] = useState<PlanningBlock[]>([]);
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [selectedBlockId, setSelectedBlockId] = useState("");
  const [message, setMessage] = useState("");

  const [form, setForm] = useState({
    training_day: new Date().toISOString().slice(0, 10),
    start_time: "09:00",
    end_time: "10:00",
    title: "",
    formation_name: "",
    instructor_name: "",
    room_name: "",
    location_type: "salle",
    block_type: "training",
    description: "",
    pedagogical_scenario_id: "",
  });

  const toast = (text: string) => {
    setMessage(text);
    window.setTimeout(() => setMessage(""), 2200);
  };

  async function reload() {
    const [{ data: blockData, error: blockError }, { data: scenarioData, error: scenarioError }] =
      await Promise.all([
        supabase
          .from("training_schedule_blocks")
          .select("*")
          .eq("cohort_id", cohortId)
          .order("training_day")
          .order("start_time"),
        supabase
          .from("pedagogical_scenarios")
          .select("*")
          .eq("cohort_id", cohortId)
          .order("updated_at", { ascending: false }),
      ]);

    if (blockError) console.error(blockError);
    if (scenarioError) console.error(scenarioError);

    const nextBlocks = (blockData ?? []) as PlanningBlock[];
    setBlocks(nextBlocks);
    setScenarios((scenarioData ?? []) as Scenario[]);

    if (nextBlocks.length) {
      const { data: assetData } = await supabase
        .from("training_schedule_assets")
        .select("*")
        .in("block_id", nextBlocks.map((block) => block.id));
      setAssets((assetData ?? []) as Asset[]);
    } else {
      setAssets([]);
    }
  }

  useEffect(() => {
    void reload();
  }, [cohortId]); // eslint-disable-line react-hooks/exhaustive-deps

  async function createBlock() {
    if (!form.title.trim()) {
      toast("Le titre du bloc est obligatoire.");
      return;
    }

    if (timeToMinutes(form.end_time) <= timeToMinutes(form.start_time)) {
      toast("L’heure de fin doit être après l’heure de début.");
      return;
    }

    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase.from("training_schedule_blocks").insert({
      cohort_id: cohortId,
      training_day: form.training_day,
      start_time: form.start_time,
      end_time: form.end_time,
      title: form.title.trim(),
      formation_name: form.formation_name.trim() || null,
      instructor_name: form.instructor_name.trim() || null,
      room_name: form.room_name.trim() || null,
      location_type: form.location_type || null,
      block_type: form.block_type,
      description: form.description.trim() || null,
      pedagogical_scenario_id: form.pedagogical_scenario_id || null,
      created_by: user.id,
    });

    if (error) {
      console.error(error);
      toast(error.message);
      return;
    }

    setForm((current) => ({
      ...current,
      title: "",
      instructor_name: "",
      room_name: "",
      description: "",
      pedagogical_scenario_id: "",
    }));

    await reload();
    toast("Bloc ajouté au planning.");
  }

  async function deleteBlock(blockId: string) {
    if (!window.confirm("Supprimer ce bloc du planning ?")) return;
    const { error } = await supabase.from("training_schedule_blocks").delete().eq("id", blockId);
    if (error) {
      toast(error.message);
      return;
    }
    if (selectedBlockId === blockId) setSelectedBlockId("");
    await reload();
  }

  async function attachScenario(blockId: string, scenarioId: string) {
    const { error } = await supabase
      .from("training_schedule_blocks")
      .update({ pedagogical_scenario_id: scenarioId || null })
      .eq("id", blockId);

    if (error) {
      toast(error.message);
      return;
    }
    await reload();
    toast("Scénario pédagogique lié.");
  }

  async function uploadAsset(blockId: string, file: File) {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const lower = file.name.toLowerCase();
    let assetType = "document";
    if (lower.endsWith(".pdf")) assetType = "pdf";
    if (lower.endsWith(".ppt") || lower.endsWith(".pptx") || lower.endsWith(".key")) assetType = "presentation";

    const clean = file.name.replace(/[^a-zA-Z0-9._-]/g, "-");
    const path = `${cohortId}/${blockId}/${crypto.randomUUID()}-${clean}`;

    const upload = await supabase.storage.from("training-assets").upload(path, file);
    if (upload.error) {
      toast(upload.error.message);
      return;
    }

    const fileUrl = supabase.storage.from("training-assets").getPublicUrl(path).data.publicUrl;
    const { error } = await supabase.from("training_schedule_assets").insert({
      block_id: blockId,
      title: file.name,
      asset_type: assetType,
      storage_path: path,
      file_url: fileUrl,
      original_filename: file.name,
      uploaded_by: user.id,
    });

    if (error) {
      toast(error.message);
      return;
    }

    await reload();
    toast("Support ajouté à l’intervention.");
  }

  const days = useMemo(() => {
    return Array.from(new Set(blocks.map((block) => block.training_day))).sort();
  }, [blocks]);

  const hours = useMemo(() => {
    if (!blocks.length) return [];
    const min = Math.min(...blocks.map((b) => timeToMinutes(b.start_time)));
    const max = Math.max(...blocks.map((b) => timeToMinutes(b.end_time)));
    const start = Math.floor(min / 30) * 30;
    const end = Math.ceil(max / 30) * 30;
    const values: number[] = [];
    for (let value = start; value <= end; value += 30) values.push(value);
    return values;
  }, [blocks]);

  const selectedBlock = blocks.find((block) => block.id === selectedBlockId) ?? null;
  const selectedAssets = selectedBlock ? assets.filter((asset) => asset.block_id === selectedBlock.id) : [];

  return (
    <section className="planning">
      {message && <div className="toast">{message}</div>}

      <div className="hero">
        <div>
          <p>PLANNING FORMATION</p>
          <h1>Organisation pédagogique</h1>
          <span>
            Inspiré de ton planning DETB : jour, horaire, formation, intervenant, salle/terrain, scénario et supports.
          </span>
        </div>
      </div>

      <div className="create-card">
        <h2>Ajouter un bloc au planning</h2>

        <div className="form-grid">
          <label>
            <span>Date</span>
            <input type="date" value={form.training_day} onChange={(e) => setForm({ ...form, training_day: e.target.value })} />
          </label>
          <label>
            <span>Début</span>
            <input type="time" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
          </label>
          <label>
            <span>Fin</span>
            <input type="time" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
          </label>
          <label>
            <span>Type</span>
            <select value={form.block_type} onChange={(e) => setForm({ ...form, block_type: e.target.value })}>
              {BLOCK_TYPES.map(([value, label]) => <option value={value} key={value}>{label}</option>)}
            </select>
          </label>
          <label>
            <span>Nom de la formation</span>
            <input value={form.formation_name} onChange={(e) => setForm({ ...form, formation_name: e.target.value })} placeholder="DETB CS1" />
          </label>
          <label>
            <span>Intervenant</span>
            <input value={form.instructor_name} onChange={(e) => setForm({ ...form, instructor_name: e.target.value })} placeholder="Nom / prénom" />
          </label>
          <label>
            <span>Salle / terrain</span>
            <input value={form.room_name} onChange={(e) => setForm({ ...form, room_name: e.target.value })} placeholder="Annexe 3 / Terrain / Salle fédérale..." />
          </label>
          <label>
            <span>Lieu</span>
            <select value={form.location_type} onChange={(e) => setForm({ ...form, location_type: e.target.value })}>
              <option value="salle">Salle</option>
              <option value="terrain">Terrain</option>
              <option value="visio">Visio</option>
              <option value="autre">Autre</option>
            </select>
          </label>
          <label className="wide">
            <span>Titre / contenu</span>
            <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Être capable de déterminer les éléments clefs du tir..." />
          </label>
          <label className="wide">
            <span>Description / consigne</span>
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </label>
          <label className="wide">
            <span>Scénario pédagogique</span>
            <select value={form.pedagogical_scenario_id} onChange={(e) => setForm({ ...form, pedagogical_scenario_id: e.target.value })}>
              <option value="">Aucun</option>
              {scenarios.map((scenario) => <option value={scenario.id} key={scenario.id}>{scenario.title}</option>)}
            </select>
          </label>
        </div>

        <button className="primary" onClick={createBlock}>+ Ajouter au planning</button>
      </div>

      <div className="board-card">
        <div className="board-head">
          <div>
            <p>VUE SEMAINE / SESSION</p>
            <h2>Planning</h2>
          </div>
          <span>Clique sur un bloc pour joindre PDF/PPT/Keynote ou changer son scénario.</span>
        </div>

        {!days.length ? (
          <div className="empty">Aucun bloc pour cette promotion.</div>
        ) : (
          <div className="table-scroll">
            <div
              className="planning-grid"
              style={{
                gridTemplateColumns: `82px repeat(${days.length}, minmax(245px, 1fr))`,
              }}
            >
              <div className="corner" />
              {days.map((day) => <div className="day-head" key={day}>{formatDay(day)}</div>)}

              {hours.map((minute) => {
                const hh = String(Math.floor(minute / 60)).padStart(2, "0");
                const mm = String(minute % 60).padStart(2, "0");
                return [
                  <div className="time-cell" key={`time-${minute}`}>{hh}:{mm}</div>,
                  ...days.map((day) => {
                    const block = blocks.find(
                      (item) =>
                        item.training_day === day &&
                        timeToMinutes(item.start_time) === minute,
                    );

                    if (!block) return <div className="slot" key={`${day}-${minute}`} />;

                    const span = Math.max(
                      1,
                      Math.round(
                        (timeToMinutes(block.end_time) - timeToMinutes(block.start_time)) / 30,
                      ),
                    );

                    return (
                      <button
                        key={`${day}-${minute}`}
                        className={`block type-${block.block_type}`}
                        style={{ gridRow: `span ${span}` }}
                        onClick={() => setSelectedBlockId(block.id)}
                      >
                        <small>{block.start_time.slice(0, 5)} - {block.end_time.slice(0, 5)}</small>
                        {block.formation_name && <em>{block.formation_name}</em>}
                        <strong>{block.title}</strong>
                        {block.instructor_name && <span>👤 {block.instructor_name}</span>}
                        {block.room_name && <span>📍 {block.room_name}</span>}
                        {block.pedagogical_scenario_id && <span>📘 Scénario lié</span>}
                      </button>
                    );
                  }),
                ];
              })}
            </div>
          </div>
        )}
      </div>

      {selectedBlock && (
        <div className="detail-card">
          <div className="detail-head">
            <div>
              <p>BLOC SÉLECTIONNÉ</p>
              <h2>{selectedBlock.title}</h2>
              <span>{selectedBlock.start_time.slice(0,5)} → {selectedBlock.end_time.slice(0,5)} · {formatDay(selectedBlock.training_day)}</span>
            </div>
            <button className="danger" onClick={() => deleteBlock(selectedBlock.id)}>Supprimer</button>
          </div>

          <div className="detail-grid">
            <label>
              <span>Scénario pédagogique</span>
              <select
                value={selectedBlock.pedagogical_scenario_id ?? ""}
                onChange={(e) => attachScenario(selectedBlock.id, e.target.value)}
              >
                <option value="">Aucun</option>
                {scenarios.map((scenario) => <option key={scenario.id} value={scenario.id}>{scenario.title}</option>)}
              </select>
            </label>

            <label className="upload">
              + Ajouter PDF / PPT / PPTX / Keynote
              <input
                hidden
                type="file"
                accept=".pdf,.ppt,.pptx,.key,.doc,.docx"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void uploadAsset(selectedBlock.id, file);
                  e.currentTarget.value = "";
                }}
              />
            </label>
          </div>

          <div className="assets">
            {selectedAssets.map((asset) => (
              <a href={asset.file_url} target="_blank" rel="noreferrer" key={asset.id}>
                <span>{asset.asset_type === "presentation" ? "🖥️" : asset.asset_type === "pdf" ? "📄" : "📎"}</span>
                <strong>{asset.title}</strong>
              </a>
            ))}
            {!selectedAssets.length && <div className="empty">Aucun support joint à cette intervention.</div>}
          </div>
        </div>
      )}

      <style jsx>{`
        .planning{display:grid;gap:14px}.hero{background:linear-gradient(135deg,#6b1a2c,#35101a);color:#fff;border-radius:23px;padding:22px}.hero p,.board-head p,.detail-head p{margin:0;color:#d4a24c;font-weight:1000;letter-spacing:.12em;font-size:.68rem}.hero h1,.board-head h2,.detail-head h2{margin:5px 0}.create-card,.board-card,.detail-card{background:#fff;border:1px solid #eadfd8;border-radius:16px;padding:16px}.form-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.form-grid label,.detail-grid label{display:grid;gap:4px}.form-grid label span,.detail-grid label span{font-size:.65rem;text-transform:uppercase;font-weight:900;color:#7c6d65}.form-grid input,.form-grid select,.form-grid textarea,.detail-grid select{border:1px solid #ddd1ca;border-radius:8px;padding:8px;width:100%}.wide{grid-column:1/-1}.primary,.upload{display:inline-block;margin-top:10px;background:#6b1a2c;color:#fff;border:0;border-radius:9px;padding:9px 12px;font-weight:950;cursor:pointer}.board-head,.detail-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.board-head>span,.detail-head>div>span{color:#85766e;font-size:.77rem}.table-scroll{overflow:auto;margin-top:12px}.planning-grid{display:grid;grid-auto-rows:42px;min-width:max-content;border:1px solid #ded4cd}.corner,.day-head,.time-cell,.slot,.block{border-right:1px solid #ded4cd;border-bottom:1px solid #ded4cd}.day-head{display:flex;align-items:center;justify-content:center;background:#2e2826;color:#fff;font-weight:950;text-transform:capitalize}.time-cell{display:flex;align-items:flex-start;justify-content:center;padding-top:4px;background:#f2efec;font-size:.72rem;font-weight:800}.slot{background:#fff;min-width:245px}.block{display:grid;align-content:start;gap:3px;text-align:left;padding:7px;background:#fff;border-top:0;border-left:0;cursor:pointer;overflow:hidden}.block small{font-weight:900}.block em{font-style:normal;color:#4b8b24;font-size:.68rem;font-weight:950}.block strong{color:#2d211d}.block span{font-size:.67rem;color:#74665f}.type-court{background:#fff9f7}.type-meeting{background:#f8f4ff}.type-meal{background:#ededed}.type-assessment{background:#fff4e8}.detail-grid{display:grid;grid-template-columns:1fr auto;gap:9px;align-items:end}.danger{border:1px solid #b42318;background:#fff;color:#b42318;border-radius:9px;padding:8px 10px;font-weight:900}.assets{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-top:12px}.assets a{display:flex;gap:8px;align-items:center;border:1px solid #eee4df;border-radius:9px;padding:9px;text-decoration:none;color:#6b1a2c}.empty{color:#897b73;padding:12px}.toast{position:fixed;top:15px;left:50%;transform:translateX(-50%);z-index:100;background:#231b18;color:#fff;border-radius:999px;padding:10px 17px;font-weight:900}@media(max-width:900px){.form-grid{grid-template-columns:1fr 1fr}.assets{grid-template-columns:1fr}.detail-grid{grid-template-columns:1fr}}@media(max-width:600px){.form-grid{grid-template-columns:1fr}.wide{grid-column:auto}}
      `}</style>
    </section>
  );
}
