"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  saveSystem,
  updateSystem,
  getSystem,
  newSystemId,
  type SystemItem,
} from "@/lib/systems";
import { uploadSchemaImage } from "@/lib/supabase/upload-schema";

type Systeme = {
  id?: string;
  title: string;
  objectif: string;
  organisation: string;
  deroulement: string;
  consignes: string;
  variantes: string;
  famille: string;
  categorie: string;
  type: string;
  tempsForts: string[];
  tags: string[];
  images: string[];
  videos: string[];
  schemaImages: string[];
  schemaDataList: any[];
  createdAt?: string | number;
};

const RETURN_KEY = "mb_plaquette_return_to";
const LOAD_KEY = "mybasket_plaquette_load";
const RESULT_KEY = "mybasket_plaquette_result";
const EDIT_INDEX_KEY = "mybasket_edit_schema_index";
const EDIT_SCHEMA_GROUP_KEY = "mybasket_edit_schema_group_id";
const EDIT_SYSTEM_ID_KEY = "mybasket_edit_system_id";
const CURRENT_SYSTEM_ID_KEY = "mybasket_current_system_id";

const DEFAULT_FAMILLES = ["Offensif"];

const DEFAULT_TEMPS_FORTS = [
  "Pick top",
  "Pick side",
  "Hand off",
  "Isolation",
  "Post-up",
  "Écran non porteur",
];

const DEFAULT_CATEGORIES = ["U13", "U15", "U18", "U21", "Seniors"];

const DEFAULT_TYPES = [
  "SLOB",
  "BLOB",
  "Homme à Homme demi terrain",
  "Attaque de Zone",
  "Transition",
];

const DEFAULT_TAGS = [
  "spacing",
  "pick-and-roll",
  "shoot",
  "corner",
  "screen",
  "handoff",
  "transition",
  "zone",
];


const blank = (): Systeme => ({
  title: "",
  objectif: "",
  organisation: "",
  deroulement: "",
  consignes: "",
  variantes: "",
  famille: "Offensif",
  categorie: "U18",
  type: "Homme à Homme demi terrain",
  tempsForts: [],
  tags: [],
  images: [],
  videos: [],
  schemaImages: [],
  schemaDataList: [],
});

function normalizeSchemaData(schema: any, index: number, image = "") {
  return {
    title: schema?.title ?? `Schéma ${index + 1}`,
    schemaGroupId: schema?.schemaGroupId ?? crypto.randomUUID(),
    phaseIndex: index,
    courtType: schema?.courtType ?? "half",
    phases: Array.isArray(schema?.phases) ? schema.phases : [],
    sheet: schema?.sheet ?? null,
    current: typeof schema?.current === "number" ? schema.current : 0,
    imageData: schema?.imageData ?? image ?? "",
    phaseImages: Array.isArray(schema?.phaseImages)
      ? schema.phaseImages
      : image
      ? [image]
      : [],
    editable: true,
  };
}

function syncSchemas(images: string[], dataList: any[]) {
  return images.map((image, index) =>
    normalizeSchemaData(dataList[index], index, image)
  );
}

function systemToForm(system: SystemItem): Systeme {
  const schemaImages = system.schemaImages || [];
  const schemaDataList = syncSchemas(schemaImages, system.schemaDataList || []);

  return {
    id: system.id,
    title: system.title || "",
    objectif: system.objectif || "",
    organisation: system.organisation || "",
    deroulement: system.deroulement || "",
    consignes: system.consignes || "",
    variantes: system.variantes || "",
    famille: system.famille || "Offensif",
    categorie: system.categorie || "U18",
    type: system.type || "Homme à Homme demi terrain",
    tempsForts: system.tempsForts || [],
    tags: system.tags || [],
    images: system.images || [],
    videos: system.videos || [],
    schemaImages,
    schemaDataList,
    createdAt: system.createdAt,
  };
}

export default function SystemesClient() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const editId = searchParams.get("id");
  const isNew = searchParams.get("new") === "1";

  const imgInput = useRef<HTMLInputElement | null>(null);
  const vidInput = useRef<HTMLInputElement | null>(null);
  const toastT = useRef<number | null>(null);

  const [systeme, setSysteme] = useState<Systeme>(blank());
  const [toast, setToast] = useState("");
  const [loading, setLoading] = useState(false);

  const tempsFortsOptions = DEFAULT_TEMPS_FORTS;
  const categories = DEFAULT_CATEGORIES;
  const types = DEFAULT_TYPES;

  const flash = (message: string) => {
    setToast(message);
    if (toastT.current) window.clearTimeout(toastT.current);
    toastT.current = window.setTimeout(() => setToast(""), 2600);
  };

  const set = <K extends keyof Systeme>(key: K, value: Systeme[K]) => {
    setSysteme((prev) => ({ ...prev, [key]: value }));
  };

  const toggleArray = (key: "tempsForts" | "tags", value: string) => {
    setSysteme((prev) => {
      const current = prev[key];

      return {
        ...prev,
        [key]: current.includes(value)
          ? current.filter((item) => item !== value)
          : [...current, value],
      };
    });
  };


  useEffect(() => {
    const load = async () => {
      let base = blank();

      try {
        const resultRaw = localStorage.getItem(RESULT_KEY);

        if (isNew) {
          localStorage.removeItem(RETURN_KEY);
          localStorage.removeItem(LOAD_KEY);
          localStorage.removeItem(RESULT_KEY);
          localStorage.removeItem(EDIT_INDEX_KEY);
          localStorage.removeItem(EDIT_SCHEMA_GROUP_KEY);
          localStorage.removeItem(EDIT_SYSTEM_ID_KEY);
          localStorage.removeItem(CURRENT_SYSTEM_ID_KEY);
          setSysteme(blank());
          return;
        }

        if (editId) {
          setLoading(true);

          const existing = await getSystem(editId);

          if (existing) {
            base = systemToForm(existing);

            if (!DEFAULT_CATEGORIES.includes(base.categorie)) {
              base.categorie = "U18";
            }

            if (!DEFAULT_TYPES.includes(base.type)) {
              base.type = "Attaque demi-terrain Homme à homme";
            }
          } else {
            flash("Système introuvable");
          }

          setLoading(false);
        }

        if (resultRaw) {
          const result = JSON.parse(resultRaw);

          const incomingImages: string[] = Array.isArray(result.schemaImages)
            ? result.schemaImages.filter(Boolean)
            : result.schemaImage
            ? [result.schemaImage]
            : [];

          const incomingData: any[] = Array.isArray(result.schemaDataList)
            ? result.schemaDataList
            : result.schemaData
            ? [result.schemaData]
            : [];

          const storedEditIndex = localStorage.getItem(EDIT_INDEX_KEY);

          const editIndex =
            typeof result.editIndex === "number"
              ? result.editIndex
              : storedEditIndex !== null
              ? Number(storedEditIndex)
              : null;

          if (incomingImages.length) {
            const nextImages = [...base.schemaImages];
            const nextData = [...base.schemaDataList];

            if (
              editIndex !== null &&
              Number.isFinite(editIndex) &&
              editIndex >= 0 &&
              editIndex < nextImages.length
            ) {
              nextImages.splice(editIndex, 1, ...incomingImages);

              nextData.splice(
                editIndex,
                1,
                ...incomingImages.map((img, idx) =>
                  normalizeSchemaData(incomingData[idx], editIndex + idx, img)
                )
              );
            } else {
              const startIndex = nextImages.length;

              nextImages.push(...incomingImages);

              incomingImages.forEach((img, idx) => {
                nextData.push(
                  normalizeSchemaData(incomingData[idx], startIndex + idx, img)
                );
              });
            }

            const limitedImages = nextImages.slice(0, 50);
            const limitedData = syncSchemas(limitedImages, nextData).slice(0, 50);

            base = {
              ...base,
              schemaImages: limitedImages,
              schemaDataList: limitedData,
            };
          }

          localStorage.removeItem(RESULT_KEY);
          localStorage.removeItem(EDIT_INDEX_KEY);
          localStorage.removeItem(LOAD_KEY);
          localStorage.removeItem(RETURN_KEY);
          localStorage.removeItem(EDIT_SYSTEM_ID_KEY);
          localStorage.removeItem(CURRENT_SYSTEM_ID_KEY);
          localStorage.removeItem(EDIT_SCHEMA_GROUP_KEY);

          flash("Schéma ajouté au système ✅");
        }

        setSysteme({
          ...base,
          schemaDataList: syncSchemas(base.schemaImages, base.schemaDataList),
        });
      } catch (error) {
        console.error(error);
        setLoading(false);
        flash("Erreur lors du chargement");
      }
    };

    load();
  }, [editId, isNew]);

  const saveDraftBeforeDraw = async () => {
    if (!systeme.title.trim()) {
      flash("Ajoute un titre avant d’ouvrir la plaquette");
      return null;
    }

    const id = editId || systeme.id || newSystemId();

    const cleanSchemaDataList = syncSchemas(
      systeme.schemaImages,
      systeme.schemaDataList
    );

    const payload: Systeme = {
      ...systeme,
      id,
      title: systeme.title.trim(),
      schemaDataList: cleanSchemaDataList,
    };

    const saved =
      editId || systeme.id
        ? await updateSystem(id, payload)
        : await saveSystem(payload);

    if (!saved) {
      flash("Impossible d’enregistrer le système avant la plaquette");
      return null;
    }

    setSysteme(systemToForm(saved));

    if (!editId) {
      router.replace(`/systemes/creer?id=${saved.id}`);
    }

    return saved;
  };

  const openDraw = async (index?: number) => {
    const saved = await saveDraftBeforeDraw();

    if (!saved) return;

    const currentId = saved.id;
    const cleanDataList = syncSchemas(
      saved.schemaImages || [],
      saved.schemaDataList || []
    );

    localStorage.setItem(EDIT_SYSTEM_ID_KEY, currentId);
    localStorage.setItem(CURRENT_SYSTEM_ID_KEY, currentId);

    localStorage.removeItem(LOAD_KEY);
    localStorage.removeItem(RESULT_KEY);
    localStorage.removeItem(EDIT_SCHEMA_GROUP_KEY);

    if (typeof index === "number") {
      localStorage.setItem(EDIT_INDEX_KEY, String(index));

      const schemaData = cleanDataList[index];
      const schemaImage = saved.schemaImages?.[index];

      const loadPayload = {
        title: schemaData?.title || `Schéma ${index + 1}`,
        editIndex: index,
        schemaGroupId: schemaData?.schemaGroupId || crypto.randomUUID(),
        courtType: schemaData?.courtType || "half",
        phases: Array.isArray(schemaData?.phases) ? schemaData.phases : [],
        sheet: schemaData?.sheet ?? null,
        current: typeof schemaData?.current === "number" ? schemaData.current : 0,
        imageData: schemaData?.imageData || schemaImage || "",
        phaseImages: Array.isArray(schemaData?.phaseImages)
          ? schemaData.phaseImages
          : schemaImage
          ? [schemaImage]
          : [],
      };

      localStorage.setItem(LOAD_KEY, JSON.stringify(loadPayload));
    } else {
      localStorage.removeItem(EDIT_INDEX_KEY);
    }

    localStorage.setItem(RETURN_KEY, `/systemes/creer?id=${currentId}`);

    router.push(
      typeof index === "number"
        ? "/plaquette?type=systeme&mode=edit"
        : "/plaquette?type=systeme&mode=new"
    );
  };

  const removeSchema = (index: number) => {
    setSysteme((prev) => {
      const nextImages = prev.schemaImages.filter((_, i) => i !== index);
      const nextData = prev.schemaDataList.filter((_, i) => i !== index);

      return {
        ...prev,
        schemaImages: nextImages,
        schemaDataList: syncSchemas(nextImages, nextData),
      };
    });
  };

  const onImages = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const room = 5 - systeme.images.length;

    files.slice(0, room).forEach((file) => {
      const reader = new FileReader();

      reader.onload = () => {
        setSysteme((prev) => ({
          ...prev,
          images: [...prev.images, reader.result as string].slice(0, 5),
        }));
      };

      reader.readAsDataURL(file);
    });

    event.target.value = "";
  };

  const removeImage = (index: number) => {
    setSysteme((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }));
  };

  const onVideos = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];

    if (!file) return;

    const reader = new FileReader();

    reader.onload = () => {
      setSysteme((prev) => ({
        ...prev,
        videos: [reader.result as string],
      }));
    };

    reader.readAsDataURL(file);
    event.target.value = "";
  };

  const removeVideo = () => {
    setSysteme((prev) => ({
      ...prev,
      videos: [],
    }));
  };

  const save = async () => {
    if (!systeme.title.trim()) {
      flash("Ajoute un titre à ton système");
      return;
    }

    setLoading(true);

    const id = editId || systeme.id || newSystemId();

    try {
      const uploadedImages = await Promise.all(
        systeme.images.map(async (img) => {
          if (img.startsWith("http")) return img;
          return uploadSchemaImage(img, "systemes-images");
        })
      );

      const cleanSchemaDataList = syncSchemas(
        systeme.schemaImages,
        systeme.schemaDataList
      );

      const payload: Systeme = {
        ...systeme,
        id,
        title: systeme.title.trim(),
        images: uploadedImages,
        schemaImages: systeme.schemaImages,
        schemaDataList: cleanSchemaDataList,
      };

      const saved =
        editId || systeme.id
          ? await updateSystem(id, payload)
          : await saveSystem(payload);

      setLoading(false);

      if (!saved) {
        flash("Erreur lors de la sauvegarde");
        return;
      }

      localStorage.removeItem(RETURN_KEY);
      localStorage.removeItem(LOAD_KEY);
      localStorage.removeItem(RESULT_KEY);
      localStorage.removeItem(EDIT_INDEX_KEY);
      localStorage.removeItem(EDIT_SCHEMA_GROUP_KEY);
      localStorage.removeItem(EDIT_SYSTEM_ID_KEY);
      localStorage.removeItem(CURRENT_SYSTEM_ID_KEY);

      flash(editId ? "Système mis à jour ✅" : "Système enregistré ✅");

      setTimeout(() => {
        router.push(`/systemes/${saved.id}`);
      }, 600);
    } catch (error) {
      console.error(error);
      setLoading(false);
      flash("Erreur lors de la sauvegarde");
    }
  };

  return (
    <div className="cs">
      <style>{CSS}</style>

      <div className="cs-topbar">
        <button className="cs-retour" onClick={() => router.push("/systemes")}>
          ← Retour aux systèmes
        </button>

        <span className="cs-nouvel">
          {editId ? "✏️ MODIFIER LE SYSTÈME" : "+ NOUVEAU SYSTÈME"}
        </span>
      </div>

      <div className="cs-title">
        <span className="dash" />
        <h1>
          {editId ? "MODIFIER UN SYSTÈME DE JEU" : "CRÉER UN SYSTÈME DE JEU"}
        </h1>
        <span className="dash" />
      </div>

      <p className="cs-sub">
        Renseigne ton système, ajoute tes schémas, puis sélectionne uniquement
        sa base, sa catégorie et ses temps forts.
      </p>

      {loading && <div className="cs-loading">Chargement...</div>}

      <div className="cs-grid">
        <div className="cs-card">
          <label className="cs-lab">
            Titre du système <b className="req">*</b>
          </label>

          <input
            className="cs-input"
            value={systeme.title}
            placeholder="Ex : Système 32-Hammer en attaque demi-terrain"
            onChange={(e) => set("title", e.target.value)}
          />

          <label className="cs-lab">Objectif du système</label>
          <textarea
            className="cs-area"
            value={systeme.objectif}
            onChange={(e) => set("objectif", e.target.value)}
          />

          <label className="cs-lab">Organisation</label>
          <textarea
            className="cs-area"
            value={systeme.organisation}
            onChange={(e) => set("organisation", e.target.value)}
          />

          <label className="cs-lab">Déroulement</label>
          <textarea
            className="cs-area big"
            value={systeme.deroulement}
            onChange={(e) => set("deroulement", e.target.value)}
          />

          <label className="cs-lab">Consignes techniques</label>
          <textarea
            className="cs-area"
            value={systeme.consignes}
            onChange={(e) => set("consignes", e.target.value)}
          />

          <label className="cs-lab">Évolution / Variantes</label>
          <textarea
            className="cs-area"
            value={systeme.variantes}
            onChange={(e) => set("variantes", e.target.value)}
          />

          <label className="cs-lab">
            Schémas du système{" "}
            <span className="cs-soft">({systeme.schemaImages.length})</span>
          </label>

          <div className="cs-schemas">
            {systeme.schemaImages.map((src, index) => (
              <div className="cs-schema" key={`${src}-${index}`}>
                <img src={src} alt={`Schéma ${index + 1}`} />

                <div className="cs-schema-actions">
                  <button type="button" onClick={() => openDraw(index)}>
                    ✏️ Modifier
                  </button>
                  <button
                    type="button"
                    className="rm"
                    onClick={() => removeSchema(index)}
                  >
                    ✕ Retirer
                  </button>
                </div>
              </div>
            ))}

            {systeme.schemaImages.length < 50 && (
              <button type="button" className="cs-draw" onClick={() => openDraw()}>
                <span>✏️</span>
                <b>Ajouter un schéma</b>
                <small>{systeme.schemaImages.length}/50 phases ajoutées</small>
              </button>
            )}
          </div>

          <label className="cs-lab">
            Vidéo / Animation <span className="cs-soft">(1 max)</span>
          </label>

          {systeme.videos[0] ? (
            <div className="cs-video">
              <video src={systeme.videos[0]} controls />
              <button type="button" className="rm" onClick={removeVideo}>
                ✕ Retirer
              </button>
            </div>
          ) : (
            <button
              type="button"
              className="cs-add-video"
              onClick={() => vidInput.current?.click()}
            >
              🎬 Ajouter une vidéo
            </button>
          )}

          <input
            ref={vidInput}
            type="file"
            accept="video/mp4,video/*"
            hidden
            onChange={onVideos}
          />

          <label className="cs-lab">
            Images / Documents <span className="cs-soft">(5 max)</span>
          </label>

          <div className="cs-imgs">
            {systeme.images.map((src, index) => (
              <div className="cs-thumb" key={`${src}-${index}`}>
                <img src={src} alt="" />
                <button type="button" onClick={() => removeImage(index)}>
                  ✕
                </button>
              </div>
            ))}

            {systeme.images.length < 5 && (
              <button
                type="button"
                className="cs-add-img"
                onClick={() => imgInput.current?.click()}
              >
                📷 Ajouter une image
              </button>
            )}

            <input
              ref={imgInput}
              type="file"
              accept="image/*"
              multiple
              hidden
              onChange={onImages}
            />
          </div>
        </div>

        <div className="cs-card cs-criteres">
          <h2>CRITÈRES</h2>

          <label className="cs-lab">Temps forts</label>

          <div className="cs-check-grid">
            {tempsFortsOptions.map((item) => (
              <label key={item} className="cs-check">
                <input
                  type="checkbox"
                  checked={systeme.tempsForts.includes(item)}
                  onChange={() => toggleArray("tempsForts", item)}
                />
                {item}
              </label>
            ))}
          </div>

          <label className="cs-lab">Catégorie</label>
          <select
            className="cs-select"
            value={systeme.categorie}
            onChange={(e) => set("categorie", e.target.value)}
          >
            {categories.map((item) => (
              <option key={item}>{item}</option>
            ))}
          </select>

          <label className="cs-lab">Type de système</label>
          <div className="cs-radio-list">
            {types.map((item) => (
              <label key={item} className="cs-radio">
                <input
                  type="radio"
                  name="type"
                  checked={systeme.type === item}
                  onChange={() => set("type", item)}
                />
                {item}
              </label>
            ))}
          </div>



          <small className="cs-help">
            Sélectionne uniquement la base, la catégorie et les temps forts du système.
          </small>
        </div>
      </div>

      <div className="cs-actions">
        <button type="button" className="cs-btn ghost" onClick={() => router.back()}>
          Annuler
        </button>

        <button type="button" className="cs-btn save" onClick={save} disabled={loading}>
          💾 {editId ? "METTRE À JOUR LE SYSTÈME" : "SAUVEGARDER LE SYSTÈME"}
        </button>
      </div>

      {toast && <div className="cs-toast">{toast}</div>}
    </div>
  );
}

const CSS = `
.cs{font-family:'Roboto',system-ui,sans-serif;background:#fff;color:#0F0F12;max-width:1280px;margin:0 auto;padding:1.4rem 1.6rem 3rem}
.cs *{box-sizing:border-box}
.cs button{font-family:inherit;cursor:pointer}
.cs button:disabled{opacity:.55;cursor:not-allowed}
.cs img{display:block;max-width:100%}
.cs-loading{background:#fff8ec;border:1px solid #f6d29b;color:#8a5a00;border-radius:12px;padding:.8rem 1rem;margin:1rem 0;font-weight:800}
.cs-topbar{display:flex;align-items:center;justify-content:space-between;gap:1rem}
.cs-retour{border:2px solid #0F0F12;background:#fff;border-radius:999px;padding:.5rem 1.1rem;font-weight:800;font-size:.95rem}
.cs-retour:hover{background:#0F0F12;color:#fff}
.cs-nouvel{font-weight:900;color:#777;letter-spacing:.04em}
.cs-title{display:flex;align-items:center;justify-content:center;gap:1.2rem;margin:1.2rem 0 .3rem}
.cs-title h1{font-weight:900;font-size:2.35rem;letter-spacing:.02em;text-align:center;margin:0}
.cs-title .dash{height:4px;width:58px;background:#0F0F12;display:inline-block}
.cs-sub{text-align:center;color:#666;max-width:760px;margin:0 auto 1.6rem}
.cs-grid{display:grid;grid-template-columns:2fr 1.25fr;gap:1.6rem;align-items:start}
.cs-card{background:#fff;border:1px solid #e4e4e4;border-radius:18px;padding:1.4rem;box-shadow:0 2px 12px rgba(0,0,0,.04)}
.cs-lab{display:block;font-weight:900;text-transform:uppercase;font-size:.82rem;letter-spacing:.03em;margin:1rem 0 .4rem}
.cs-lab:first-of-type{margin-top:0}
.cs-soft{font-weight:500;text-transform:none;color:#888}
.req{color:#C0392B}
.cs-input,.cs-area,.cs-select{width:100%;border:1px solid #d6d6d6;border-radius:10px;padding:.7rem .9rem;font-size:.95rem;font-family:inherit;background:#f7f7f7}
.cs-input:focus,.cs-area:focus,.cs-select:focus{outline:2px solid #6B1A2C;border-color:#6B1A2C;background:#fff}
.cs-area{min-height:105px;resize:vertical}
.cs-area.big{min-height:150px}
.cs-help{display:block;color:#777;font-size:.78rem;margin-top:.35rem}
.cs-schemas{display:grid;grid-template-columns:repeat(2,1fr);gap:.8rem}
.cs-draw{min-height:170px;width:100%;border:2px dashed #cfcfcf;background:#f6f6f6;border-radius:14px;padding:1.2rem;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:.3rem}
.cs-draw:hover{background:#f0f0f0;border-color:#6B1A2C}
.cs-draw span{font-size:1.8rem}
.cs-draw b{font-size:1.05rem}
.cs-draw small{color:#888}
.cs-schema{border:1px solid #e0e0e0;border-radius:14px;overflow:hidden;background:#fafafa}
.cs-schema img{width:100%;height:190px;object-fit:contain;background:#fff}
.cs-schema-actions{display:flex;gap:.6rem;padding:.7rem;border-top:1px solid #eee}
.cs-schema-actions button{flex:1;border:1px solid #d6d6d6;background:#fff;border-radius:8px;padding:.45rem .8rem;font-weight:700;font-size:.85rem}
.cs-schema-actions .rm,.cs-video .rm{color:#C0392B;border-color:#F2C3C3}
.cs-video{border:1px solid #e0e0e0;border-radius:12px;overflow:hidden}
.cs-video video{width:100%;display:block;background:#000;max-height:320px}
.cs-video .rm{width:100%;border:none;border-top:1px solid #eee;background:#fff;padding:.5rem;font-weight:700;font-size:.85rem}
.cs-add-video{border:2px dashed #6B1A2C;color:#6B1A2C;background:#fff;border-radius:10px;padding:.7rem 1rem;font-weight:700;font-size:.9rem;text-align:center}
.cs-add-video:hover{background:#FBEFF1}
.cs-imgs{display:flex;flex-wrap:wrap;gap:.6rem;align-items:center}
.cs-thumb{position:relative;width:90px;height:90px;border-radius:10px;overflow:hidden;border:1px solid #ddd}
.cs-thumb img{width:100%;height:100%;object-fit:cover}
.cs-thumb button{position:absolute;top:3px;right:3px;width:22px;height:22px;border:none;border-radius:50%;background:rgba(0,0,0,.65);color:#fff;font-size:.7rem}
.cs-add-img{border:2px dashed #D4A24C;color:#B8860B;background:#fff;border-radius:10px;padding:.7rem 1rem;font-weight:700;font-size:.9rem}
.cs-add-img:hover{background:#FFF8EC}
.cs-criteres h2{font-weight:900;font-size:1.3rem;letter-spacing:.02em;border-bottom:2px solid #eee;padding-bottom:.6rem;margin:0 0 .8rem}
.cs-check-grid{display:grid;grid-template-columns:1fr 1fr;gap:.45rem}
.cs-check,.cs-radio,.cs-tag{display:flex;align-items:center;gap:.5rem;background:#f6f6f6;border:1px solid #ececec;border-radius:8px;padding:.55rem .7rem;font-size:.9rem}
.cs-check input,.cs-radio input,.cs-tag input{width:16px;height:16px;accent-color:#6B1A2C}
.cs-radio-list{display:grid;grid-template-columns:1fr;gap:.45rem}
.cs-tags{display:grid;grid-template-columns:1fr 1fr;gap:.45rem}
.cs-actions{display:flex;justify-content:flex-end;gap:.8rem;margin-top:1.6rem}
.cs-btn{border-radius:999px;padding:.8rem 1.5rem;font-weight:800;font-size:.95rem;border:2px solid #0F0F12;background:#fff;color:#0F0F12}
.cs-btn.ghost:hover{background:#f2f2f2}
.cs-btn.save{background:#0F0F12;color:#fff;letter-spacing:.02em}
.cs-btn.save:hover{background:#000}
.cs-toast{position:fixed;bottom:1.2rem;left:50%;transform:translateX(-50%);background:#0F0F12;color:#fff;padding:.6rem 1.1rem;border-radius:10px;font-weight:600;font-size:.9rem;z-index:5000;box-shadow:0 8px 24px rgba(0,0,0,.3)}
@media (max-width:900px){
  .cs-grid,.cs-schemas{grid-template-columns:1fr}
  .cs-title h1{font-size:1.8rem}
  .cs-title .dash{width:28px}
  .cs-actions{flex-wrap:wrap}
  .cs-check-grid,.cs-tags{grid-template-columns:1fr}
}
`;