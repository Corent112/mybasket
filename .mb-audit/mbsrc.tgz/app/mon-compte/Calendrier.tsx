"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { getTeams } from "@/lib/equipes-store";

/* =====================================================================
 * MonCalendrier — transposition fidèle du calendrier de mybasket-app_24.html
 * (markup #accCalendrierSection, CSS .cal-grid/.cal-h/.cal-d/.ev,
 *  fonction renderCalendar, getEventColor, légende). Styles scopés .mb-cal.
 *
 * MODIF : l’« Équipe associée » et les événements proviennent désormais de Supabase.
 * ===================================================================== */

type EventType = "match" | "entrainement" | "tournoi" | "autre";
type Venue = "home" | "away" | "";

type Attachment = {
  name: string;
  type: string;
  dataUrl: string;
};

type CalEvent = {
  id: string;
  date: string;
  title: string;
  type: EventType;
  venue?: Venue;
  opponent?: string;
  time?: string;
  loc?: string;
  teamId?: string;
  teamName?: string;
  theme?: string;
  sessionId?: string;
  assignedPlayers?: string[];
  notes?: string;
  attachment?: Attachment;
};

type Player = {
  id: string;
  firstName: string;
  lastName?: string;
  position?: string;
  number?: string;
  avatarUrl?: string;
};

type Team = {
  id: string;
  name: string;
  logoUrl?: string;
  players: Player[];
  ownerUserId?: string | null;
  isShared?: boolean;
  collaborationPermissions?: Record<string, boolean> | null;
};

type CalendarDbRow = Record<string, unknown>;

type SessionCalendarRow = {
  id: string;
  team_id?: string | null;
  team_reference_id?: string | null;
  team_name?: string | null;
  title?: string | null;
  theme?: string | null;
  pdf_url?: string | null;
};


const MONTHS = ["JANVIER", "FÉVRIER", "MARS", "AVRIL", "MAI", "JUIN", "JUILLET", "AOÛT", "SEPTEMBRE", "OCTOBRE", "NOVEMBRE", "DÉCEMBRE"];
const DAYS = ["L", "M", "M", "J", "V", "S", "D"];

const uid = () => Math.random().toString(36).slice(2, 9);
const pad = (n: number) => String(n).padStart(2, "0");
const isPdf = (a: Attachment) => a.type === "application/pdf" || a.name.toLowerCase().endsWith(".pdf");
const isImage = (a: Attachment) => a.type.startsWith("image/");

// ── Équipes réelles depuis Supabase (mapping souple des champs) ──
function normalizeTeamForCalendar(team: any): Team {
  return {
    id: String(team.id ?? ""),
    name: String(team.nom || team.name || team.teamName || "Équipe"),
    ownerUserId: team.ownerUserId || team.user_id || null,
    isShared: team.isShared === true,
    collaborationPermissions:
      team.collaborationPermissions && typeof team.collaborationPermissions === "object"
        ? team.collaborationPermissions
        : null,
    logoUrl: String(
      team.logo ||
        team.logoUrl ||
        team.logo_url ||
        team.clubLogo ||
        team.clubLogoUrl ||
        team.club_logo_url ||
        "",
    ),
    players: (team.players || team.joueurs || team.effectif || team.roster || []).map((p: any) => ({
      id: String(p.id ?? p.playerId ?? uid()),
      firstName:
        p.prenom ||
        p.first_name ||
        p.firstName ||
        (p.name ? String(p.name).split(/\s+/)[0] : "") ||
        "Joueur",
      lastName: p.nom || p.last_name || p.lastName || "",
      position: p.position_primary || p.position || "",
      number: String(p.jersey_number || p.number || p.numero || p.num || ""),
      avatarUrl: String(p.avatar_url || p.photo_url || p.image_url || ""),
    })),
  };
}

function dbTypeToCalendarType(value: string | null | undefined): EventType {
  const type = String(value ?? "").toLowerCase();

  if (type === "game" || type === "match") return "match";
  if (type === "training" || type === "entrainement" || type === "entraînement") return "entrainement";
  if (type === "formation" || type === "tournoi") return "tournoi";

  return "autre";
}

function calendarTypeToDbType(value: EventType): string {
  if (value === "match") return "game";
  if (value === "entrainement") return "training";
  if (value === "tournoi") return "formation";

  return "other";
}

function normalizeCalendarRow(row: CalendarDbRow): CalEvent {
  const value = row as Record<string, any>;

  return {
    id: String(value.id ?? ""),
    date: String(value.event_date ?? ""),
    title: String(value.title ?? "Évènement"),
    type: dbTypeToCalendarType(value.event_type),
    time: value.start_time ? String(value.start_time).slice(0, 5) : undefined,
    loc: value.location ?? undefined,
    notes: value.description ?? undefined,
    teamId: value.team_id ? String(value.team_id) : undefined,
    teamName: value.team_name ? String(value.team_name) : undefined,
    theme: value.theme ? String(value.theme) : undefined,
    sessionId: value.session_id ? String(value.session_id) : undefined,
    assignedPlayers: Array.isArray(value.assigned_player_ids)
      ? value.assigned_player_ids.map(String)
      : [],
    attachment: value.attachment_url
      ? {
          name: "Fiche séance",
          type: "application/pdf",
          dataUrl: String(value.attachment_url),
        }
      : undefined,
  };
}

// Schéma de couleurs identique au HTML de référence (getEventColor)
function getEventColor(ev: CalEvent): { bg: string; fg: string } {
  if (ev.type === "match") {
    if (ev.venue === "away") return { bg: "#E63946", fg: "#fff" };
    if (ev.venue === "home") return { bg: "#16A34A", fg: "#fff" };
    return { bg: "#6B7280", fg: "#fff" };
  }
  if (ev.type === "entrainement") return { bg: "#2563EB", fg: "#fff" };
  if (ev.type === "tournoi") return { bg: "#F59E0B", fg: "#fff" };
  return { bg: "#60A5FA", fg: "#fff" };
}
function venueLabel(ev: CalEvent): string {
  if (ev.type === "match") return ev.venue === "home" ? "🏠 " : ev.venue === "away" ? "🚌 " : "🏀 ";
  if (ev.type === "entrainement") return "🏋 ";
  if (ev.type === "tournoi") return "🏆 ";
  return "📌 ";
}

// Ouvre la pièce jointe dans une nouvelle fenêtre et lance l'impression
function printAttachment(att: Attachment) {
  const win = window.open("", "_blank", "width=900,height=700");
  if (!win) { window.alert("Autorise les pop-ups pour imprimer la pièce jointe."); return; }
  const safeName = att.name.replace(/[<>&"]/g, "");
  let content: string;
  if (isImage(att)) {
    content = `<img src="${att.dataUrl}" style="max-width:100%;display:block;margin:0 auto" />`;
  } else if (isPdf(att)) {
    content = `<iframe src="${att.dataUrl}" style="border:0;width:100%;height:100vh"></iframe>`;
  } else {
    content = `<p style="font-family:sans-serif">Fichier : ${safeName}</p>` +
      `<a href="${att.dataUrl}" download="${safeName}">Télécharger le fichier</a>`;
  }
  win.document.write(
    `<!doctype html><html><head><meta charset="utf-8"><title>${safeName}</title>` +
    `<style>html,body{margin:0;padding:0}</style></head>` +
    `<body onload="setTimeout(function(){try{window.focus();window.print();}catch(e){}},400)">${content}</body></html>`
  );
  win.document.close();
}

export default function MonCalendrier() {
  const supabase = createClient();

  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth()); // 0..11
  const [events, setEvents] = useState<CalEvent[]>([]);
  const [loading, setLoading] = useState(true);

  // Équipes réelles (« Mes équipes »)
  const [teams, setTeams] = useState<Team[]>([]);

  // Modale événement (créer / éditer)
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [fTitle, setFTitle] = useState("");
  const [fDate, setFDate] = useState("");
  const [fTime, setFTime] = useState("");
  const [fType, setFType] = useState<EventType>("entrainement");
  const [fVenue, setFVenue] = useState<Venue>("home");
  const [fOpp, setFOpp] = useState("");
  const [fLoc, setFLoc] = useState("");
  const [fTeam, setFTeam] = useState<string>("");
  const [fPlayers, setFPlayers] = useState<string[]>([]);
  const [fNotes, setFNotes] = useState("");
  const [fAttach, setFAttach] = useState<Attachment | null>(null);

  // Modales de prévisualisation
  const [preview, setPreview] = useState<Attachment | null>(null);
  const [sessionPreviewId, setSessionPreviewId] = useState<string | null>(null);

  const togglePlayer = (pid: string) =>
    setFPlayers((p) => (p.includes(pid) ? p.filter((x) => x !== pid) : [...p, pid]));
  const selectedTeam = teams.find((t) => t.id === fTeam) || null;

  // Upload → stocke name / type / dataUrl via FileReader
  const onAttach = (file?: File) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setFAttach({ name: file.name, type: file.type, dataUrl: String(reader.result || "") });
    reader.readAsDataURL(file);
  };

  /* Chargement Supabase au montage */
  useEffect(() => {
    initialize();
  }, []);

  async function initialize() {
    await Promise.all([loadTeams(), loadEvents()]);
  }

  async function loadTeams() {
    try {
      const loadedTeams = await getTeams();
      let normalizedTeams = (loadedTeams ?? [])
        .map(normalizeTeamForCalendar)
        .filter(
          (team) =>
            Boolean(team.id) &&
            (
              // Le coach principal voit toujours le calendrier de son équipe.
              !team.isShared ||
              // Un collaborateur ne le voit QUE si la case
              // "Séances & calendrier" lui a été accordée.
              team.collaborationPermissions?.sessions === true
            ),
        );

      const teamIds = normalizedTeams.map((team) => team.id);
      if (teamIds.length > 0) {
        const { data: playerRows } = await supabase
          .from("players")
          .select("id, team_id, first_name, last_name, position_primary, jersey_number, avatar_url")
          .in("team_id", teamIds)
          .order("last_name", { ascending: true });

        const playersByTeam = new Map<string, Player[]>();
        for (const row of playerRows ?? []) {
          const teamKey = String(row.team_id || "");
          const player: Player = {
            id: String(row.id),
            firstName: String(row.first_name || "Joueur"),
            lastName: String(row.last_name || ""),
            position: String(row.position_primary || ""),
            number: String(row.jersey_number || ""),
            avatarUrl: String(row.avatar_url || ""),
          };
          playersByTeam.set(teamKey, [...(playersByTeam.get(teamKey) || []), player]);
        }

        normalizedTeams = normalizedTeams.map((team) => ({
          ...team,
          players: playersByTeam.get(team.id)?.length
            ? playersByTeam.get(team.id) || []
            : team.players,
        }));
      }

      setTeams(normalizedTeams);
    } catch (error) {
      console.error("Erreur chargement équipes calendrier:", error);
      setTeams([]);
    }
  }

  async function loadEvents() {
    setLoading(true);

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      setEvents([]);
      setLoading(false);
      return;
    }

    const loadedTeams = await getTeams().catch(() => []);
    const calendarTeamIds = (loadedTeams ?? [])
      .filter(
        (team: any) =>
          team?.isShared !== true ||
          team?.collaborationPermissions?.sessions === true,
      )
      .map((team: any) => String(team?.id || ""))
      .filter(Boolean);

    const ownQuery = supabase
      .from("calendar_events")
      .select("*")
      .or(`user_id.eq.${user.id},owner_id.eq.${user.id}`)
      .order("event_date", { ascending: true })
      .order("start_time", { ascending: true });

    const [ownResult, teamResult] = await Promise.all([
      ownQuery,
      calendarTeamIds.length
        ? supabase
            .from("calendar_events")
            .select("*")
            .in("team_id", calendarTeamIds)
            .order("event_date", { ascending: true })
            .order("start_time", { ascending: true })
        : Promise.resolve({ data: [], error: null }),
    ]);

    if (ownResult.error || teamResult.error) {
      const error = ownResult.error || teamResult.error;
      console.error("Erreur chargement calendrier:", error);
      setEvents([]);
      setLoading(false);
      return;
    }

    const rowsById = new Map<string, CalendarDbRow>();
    for (const row of [
      ...((ownResult.data ?? []) as CalendarDbRow[]),
      ...((teamResult.data ?? []) as CalendarDbRow[]),
    ]) {
      const id = String((row as Record<string, unknown>).id || "");
      if (id) rowsById.set(id, row);
    }

    const normalizedEvents: CalEvent[] = Array.from(rowsById.values())
      .map((row) => normalizeCalendarRow(row))
      .sort(
        (a, b) =>
          a.date.localeCompare(b.date) ||
          String(a.time || "").localeCompare(String(b.time || "")),
      );

    const sessionIds: string[] = normalizedEvents
      .map((event: CalEvent) => event.sessionId)
      .filter((value: string | undefined): value is string => Boolean(value));

    if (sessionIds.length > 0) {
      const { data: sessionRows } = await supabase
        .from("practice_sessions")
        .select("id, team_id, team_reference_id, team_name, title, theme, pdf_url")
        .in("id", sessionIds);

      const typedSessionRows = (sessionRows ?? []) as SessionCalendarRow[];
      const sessionsById = new Map<string, SessionCalendarRow>(
        typedSessionRows.map((row: SessionCalendarRow) => [
          String(row.id),
          row,
        ]),
      );

      for (const event of normalizedEvents) {
        if (!event.sessionId) continue;
        const relatedSession = sessionsById.get(event.sessionId);
        if (!relatedSession) continue;

        event.teamId = event.teamId || String(relatedSession.team_reference_id || relatedSession.team_id || "");
        event.teamName =
          event.teamName ||
          String(relatedSession.team_name || "") ||
          teams.find((team) => team.id === event.teamId)?.name ||
          String(relatedSession.title || "");
        event.theme = event.theme || String(relatedSession.theme || relatedSession.title || "");

        if (!event.attachment && relatedSession.pdf_url) {
          event.attachment = {
            name: "Fiche séance",
            type: "application/pdf",
            dataUrl: String(relatedSession.pdf_url),
          };
        }
      }
    }

    setEvents(normalizedEvents);
    setLoading(false);
  }

  /* Navigation mois (identique calPrev/calNext) */
  const prev = () => { if (month === 0) { setMonth(11); setYear((y) => y - 1); } else setMonth((m) => m - 1); };
  const next = () => { if (month === 11) { setMonth(0); setYear((y) => y + 1); } else setMonth((m) => m + 1); };

  /* Calcul grille (identique renderCalendar) */
  const startDay = (new Date(year, month, 1).getDay() + 6) % 7;
  const dim = new Date(year, month + 1, 0).getDate();
  const title = `${MONTHS[month]} ${year}`;

  /* Modale événement */
  const openCreate = (ds: string) => {
    setEditingId(null);
    setFTitle(""); setFDate(ds); setFTime(""); setFType("entrainement");
    setFVenue("home"); setFOpp(""); setFLoc("");
    setFTeam(""); setFPlayers([]); setFNotes(""); setFAttach(null);
    setOpen(true);
  };
  const openEdit = (id: string) => {
    const e = events.find((x) => x.id === id); if (!e) return;
    setEditingId(id);
    setFTitle(e.theme || e.title); setFDate(e.date); setFTime(e.time || ""); setFType(e.type);
    setFVenue(e.venue || "home"); setFOpp(e.opponent || ""); setFLoc(e.loc || "");
    setFTeam(e.teamId || ""); setFPlayers(e.assignedPlayers || []);
    setFNotes(e.notes || ""); setFAttach(e.attachment || null);
    setOpen(true);
  };
  const saveEvent = async () => {
    if (!fDate) return; // seule la date est requise (le titre est optionnel)

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      window.alert("Connecte-toi pour enregistrer un événement.");
      return;
    }

    const editingEvent = events.find((event) => event.id === editingId);
    const targetTeam =
      teams.find((team) => team.id === fTeam) ||
      teams.find((team) => team.id === editingEvent?.teamId) ||
      null;
    const teamOwnerId = targetTeam?.ownerUserId || user.id;

    if (
      targetTeam?.isShared &&
      targetTeam.collaborationPermissions?.sessions !== true
    ) {
      window.alert(
        "Le coach principal ne t’a pas donné accès aux séances et au calendrier de cette équipe.",
      );
      return;
    }

    const payload = {
      user_id: user.id,
      owner_id: teamOwnerId,
      title: `${selectedTeam?.name || editingEvent?.teamName || "Équipe"} • ${fTitle.trim() || "Entraînement"}`,
      theme: fTitle.trim() || "Entraînement",
      description: fNotes || null,
      event_date: fDate,
      start_time: fTime || null,
      end_time: null,
      location: fLoc || null,
      event_type: calendarTypeToDbType(fType),
      session_id:
        events.find((event) => event.id === editingId)?.sessionId || null,
      team_id:
        fTeam ||
        events.find((event) => event.id === editingId)?.teamId ||
        null,
      team_name:
        selectedTeam?.name ||
        events.find((event) => event.id === editingId)?.teamName ||
        null,
      assigned_player_ids: fPlayers,
      attachment_url:
        fAttach?.dataUrl ||
        events.find((event) => event.id === editingId)?.attachment?.dataUrl ||
        null,
      visibility: "private",
      updated_at: new Date().toISOString(),
    };

    if (editingId) {
      const { error } = await supabase
        .from("calendar_events")
        .update(payload)
        .eq("id", editingId);

      if (error) {
        console.error("Erreur modification événement:", {
          code: error.code,
          message: error.message,
          details: error.details,
          hint: error.hint,
        });
        window.alert(`Impossible de modifier l'événement : ${error.message}`);
        return;
      }
    } else {
      const { error } = await supabase.from("calendar_events").insert(payload);

      if (error) {
        console.error("Erreur création événement:", {
          code: error.code,
          message: error.message,
          details: error.details,
          hint: error.hint,
        });
        window.alert(`Impossible de créer l'événement : ${error.message}`);
        return;
      }
    }

    await loadEvents();
    setOpen(false);
  };

  async function consultSessionPdf(eventId: string) {
    const calendarEvent = events.find((event) => event.id === eventId);
    if (!calendarEvent?.sessionId) {
      window.alert("Aucune fiche séance n’est associée à cet événement.");
      return;
    }

    if (calendarEvent.attachment?.dataUrl) {
      setPreview(calendarEvent.attachment);
      return;
    }

    try {
      const response = await fetch(
        `/api/seances/${calendarEvent.sessionId}/pdf`,
        { method: "POST" },
      );
      const result = (await response.json()) as {
        pdfUrl?: string;
        error?: string;
      };

      if (!response.ok || !result.pdfUrl) {
        throw new Error(result.error || "Le PDF n’a pas pu être généré.");
      }

      const attachment: Attachment = {
        name: "Fiche séance",
        type: "application/pdf",
        dataUrl: result.pdfUrl,
      };

      setEvents((current) =>
        current.map((event) =>
          event.id === eventId
            ? { ...event, attachment }
            : event,
        ),
      );
      setFAttach(attachment);
      setPreview(attachment);
    } catch (error) {
      console.error("Erreur consultation fiche séance:", error);
      window.alert(
        error instanceof Error
          ? error.message
          : "Impossible d’ouvrir la fiche séance.",
      );
    }
  }

  const deleteEvent = async () => {
    if (!editingId) return;

    const eventToDelete = events.find((event) => event.id === editingId);
    if (!eventToDelete) return;

    const linkedSessionId = eventToDelete.sessionId;
    const confirmed = window.confirm(
      linkedSessionId
        ? "Supprimer définitivement cette séance ? Elle disparaîtra du calendrier, de la fiche équipe et de toutes les statistiques de séance."
        : "Supprimer cet événement ?",
    );
    if (!confirmed) return;

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user) {
      window.alert("Connecte-toi pour supprimer un événement.");
      return;
    }

    if (linkedSessionId) {
      // Vérifie explicitement que la séance appartient bien à l'utilisateur courant.
      // Le compte CEO/superadmin ne reçoit aucun passe-droit dans cet espace personnel.
      const { data: linkedSession, error: sessionLookupError } = await supabase
        .from("practice_sessions")
        .select("id, user_id, owner_id, team_id")
        .eq("id", linkedSessionId)
        .maybeSingle();

      if (sessionLookupError) {
        console.error("Erreur vérification séance liée:", sessionLookupError);
        window.alert(`Impossible de vérifier la séance : ${sessionLookupError.message}`);
        return;
      }

      if (linkedSession) {
        const ownerIds = [linkedSession.user_id, linkedSession.owner_id]
          .map((value) => String(value || ""))
          .filter(Boolean);
        const isSessionOwner = ownerIds.includes(user.id);

        if (!isSessionOwner && linkedSession.team_id) {
          const { data: canEditSession, error: permissionError } =
            await supabase.rpc("team_member_has_permission", {
              p_team_id: linkedSession.team_id,
              p_permission: "sessions",
            });

          if (permissionError || canEditSession !== true) {
            window.alert("Tu n’as pas l’autorisation de supprimer cette séance.");
            return;
          }
        } else if (!isSessionOwner && !linkedSession.team_id) {
          window.alert("Cette séance ne t’appartient pas.");
          return;
        }

        const sessionChildren = [
          "practice_session_attendance",
          "practice_session_players",
          "practice_session_exercises",
        ];

        for (const table of sessionChildren) {
          const { error: childError } = await supabase
            .from(table)
            .delete()
            .eq("session_id", linkedSessionId);

          if (childError) {
            const optionalTableMissing =
              childError.code === "PGRST204" ||
              childError.code === "PGRST205" ||
              childError.message?.includes("schema cache") ||
              childError.message?.includes("Could not find");

            if (!optionalTableMissing) {
              console.error(`Erreur suppression ${table}:`, childError);
              window.alert(
                `Impossible de supprimer complètement la séance : ${childError.message}`,
              );
              return;
            }
          }
        }

        const { data: deletedSessionRows, error: sessionDeleteError } = await supabase
          .from("practice_sessions")
          .delete()
          .eq("id", linkedSessionId)
          .select("id");

        if (sessionDeleteError) {
          console.error("Erreur suppression séance liée:", sessionDeleteError);
          window.alert(
            `Impossible de supprimer la séance de MyBasket : ${sessionDeleteError.message}`,
          );
          return;
        }

        if (!deletedSessionRows || deletedSessionRows.length === 0) {
          window.alert(
            "La séance n’a pas été supprimée. Vérifie les droits Supabase/RLS avant de réessayer.",
          );
          return;
        }
      }

      // Supprime toutes les représentations calendrier de cette même séance
      // appartenant à l'utilisateur courant.
      const { error: calendarDeleteError } = await supabase
        .from("calendar_events")
        .delete()
        .eq("session_id", linkedSessionId);

      if (calendarDeleteError) {
        console.error("Erreur suppression calendrier séance:", calendarDeleteError);
        window.alert(
          `La séance a été supprimée, mais le calendrier n’a pas pu être nettoyé : ${calendarDeleteError.message}`,
        );
        await loadEvents();
        return;
      }

      // Nettoyage des anciens caches locaux historiques pour empêcher toute réapparition
      // d'une séance supprimée sur un navigateur ayant utilisé une ancienne version de MyBasket.
      if (typeof window !== "undefined") {
        for (const key of [
          "mybasket_team_practice_sessions",
          "mybasket_sessions",
          "mybasket_seances",
          "practice_sessions",
        ]) {
          try {
            const parsed = JSON.parse(window.localStorage.getItem(key) || "[]");
            if (!Array.isArray(parsed)) continue;
            const cleaned = parsed.filter(
              (row: Record<string, unknown>) => String(row?.id || "") !== linkedSessionId,
            );
            if (cleaned.length !== parsed.length) {
              window.localStorage.setItem(key, JSON.stringify(cleaned));
            }
          } catch {
            // Ancien cache illisible : on l'ignore, Supabase reste la source unique.
          }
        }
      }

      setEvents((previous) =>
        previous.filter((event) => event.sessionId !== linkedSessionId),
      );
      setOpen(false);
      return;
    }

    // Événement simple : on ne touche à aucune séance, aucun match, aucune équipe ni aucun joueur.
    const { data: deletedEventRows, error } = await supabase
      .from("calendar_events")
      .delete()
      .eq("id", editingId)
      .select("id");

    if (error) {
      console.error("Erreur suppression événement:", {
        code: error.code,
        message: error.message,
        details: error.details,
        hint: error.hint,
      });
      window.alert(`Impossible de supprimer l'événement : ${error.message}`);
      return;
    }

    if (!deletedEventRows || deletedEventRows.length === 0) {
      window.alert("L'événement n'a pas été supprimé.");
      return;
    }

    setEvents((previous) => previous.filter((event) => event.id !== editingId));
    setOpen(false);
  };

  if (loading) {
    return (
      <div className="mb-cal">
        <div className="cal-head">
          <h2 className="cal-title">{title}</h2>
        </div>
        <p style={{ color: "#6B6B6B", fontWeight: 700 }}>Chargement du calendrier...</p>
        {sessionPreviewId && (
        <div
          className="cal-overlay cal-session-overlay"
          onClick={() => setSessionPreviewId(null)}
        >
          <div
            className="cal-session-preview"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="cal-modal-head">
              <div>
                <span>FICHE SÉANCE</span>
                <b>
                  {events.find((event) => event.sessionId === sessionPreviewId)
                    ?.title || "Séance"}
                </b>
              </div>
              <button
                className="cal-x"
                onClick={() => setSessionPreviewId(null)}
                aria-label="Fermer"
              >
                ✕
              </button>
            </div>
            <iframe
              src={`/seances/${sessionPreviewId}?embed=1`}
              title="Aperçu de la fiche séance"
            />
          </div>
        </div>
      )}

      <style jsx>{`
          .mb-cal{
            --bordeaux:#6B1A2C; --or:#D4A24C; --or-l:#E8C078;
            --noir:#0F0F12; --blanc:#FFFFFF;
            --gris-bg:#F5F5F5; --gris-med:#C8C8C8; --gris-text:#6B6B6B; --rouge:#E63946;
            --varsity:'Alfa Slab One',serif;
            color:var(--noir);
          }
          .cal-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:.85rem;flex-wrap:wrap;gap:.5rem}
          .cal-title{font-family:var(--varsity);letter-spacing:.05em;margin:0}
        `}</style>
      </div>
    );
  }

  return (
    <div className="mb-cal">
      {/* En-tête : titre + navigation + ajout (markup d'origine) */}
      <div className="cal-head">
        <h2 className="cal-title">{title}</h2>
        <div className="cal-actions">
          <button className="btn btn-outline btn-small" onClick={prev}>‹</button>
          <button className="btn btn-outline btn-small" onClick={next}>›</button>
          <button className="btn btn-black btn-small" onClick={() => openCreate(`${year}-${pad(month + 1)}-${pad(today.getDate())}`)}>+ Événement</button>
        </div>
      </div>

      {/* Grille calendrier */}
      <div className="cal-grid">
        {DAYS.map((d, i) => <div key={"h" + i} className="cal-h">{d}</div>)}
        {Array.from({ length: startDay }).map((_, i) => <div key={"e" + i} className="cal-d empty" />)}
        {Array.from({ length: dim }).map((_, i) => {
          const d = i + 1;
          const ds = `${year}-${pad(month + 1)}-${pad(d)}`;
          const evs = events.filter((e) => e.date === ds);
          const isT = year === today.getFullYear() && month === today.getMonth() && d === today.getDate();
          return (
            <div key={"d" + d} className={"cal-d" + (isT ? " today" : "")} onClick={() => openCreate(ds)}>
              <div className="dn">{d}</div>
              {evs.map((e) => {
                const col = getEventColor(e);
                const tip = `${e.title}${e.opponent ? " vs " + e.opponent : ""}${e.time ? " · " + e.time : ""}${e.venue === "home" ? " · 🏠 Domicile" : e.venue === "away" ? " · 🚌 Extérieur" : ""}${e.loc ? " · " + e.loc : ""}`;
                return (
                  <div
                    key={e.id}
                    className="ev"
                    style={{ background: col.bg, color: col.fg }}
                    title={tip}
                    onClick={(ev) => { ev.stopPropagation(); openEdit(e.id); }}
                  >
                    {venueLabel(e)}{e.title}
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>

      {/* Légende (markup d'origine) */}
      <div className="cal-legend">
        <span className="leg-title">Légende :</span>
        <span className="leg-item"><span className="leg-sw" style={{ background: "#16A34A" }} />🏠 Match domicile</span>
        <span className="leg-item"><span className="leg-sw" style={{ background: "#E63946" }} />🚌 Match extérieur</span>
        <span className="leg-item"><span className="leg-sw" style={{ background: "#2563EB" }} />🏋 Entraînement</span>
        <span className="leg-item"><span className="leg-sw" style={{ background: "#F59E0B" }} />🏆 Tournoi</span>
        <span className="leg-item"><span className="leg-sw" style={{ background: "#60A5FA" }} />📌 Autre</span>
      </div>

      {/* Modale créer / éditer (enrichie) */}
      {open && (
        <div className="cal-overlay" onClick={() => setOpen(false)}>
          <div className="cal-modal" onClick={(e) => e.stopPropagation()}>
            <div className="cal-modal-head">
              <b>{editingId ? "Modifier l'événement" : "Nouvel événement"}</b>
              <button className="cal-x" onClick={() => setOpen(false)} aria-label="Fermer">✕</button>
            </div>

            <div className="cal-body">
              <div className="cal-row2">
                <div className="cal-fld">
                  <label>Date <span className="req">*</span></label>
                  <input type="date" value={fDate} onChange={(e) => setFDate(e.target.value)} />
                </div>
                <div className="cal-fld">
                  <label>Heure</label>
                  <input type="time" value={fTime} onChange={(e) => setFTime(e.target.value)} />
                </div>
              </div>

              <div className="cal-fld">
                <label>Type</label>
                <select value={fType} onChange={(e) => setFType(e.target.value as EventType)}>
                  <option value="match">Match</option>
                  <option value="entrainement">Entraînement</option>
                  <option value="tournoi">Tournoi</option>
                  <option value="autre">Autre</option>
                </select>
              </div>

              <div className="cal-fld">
                <label>Équipe associée</label>
                {editingId && events.find((event) => event.id === editingId)?.sessionId ? (
                  <div className="cal-readonly-team">
                    <strong>{events.find((event) => event.id === editingId)?.teamName || selectedTeam?.name || "Équipe associée"}</strong>
                    <small>Équipe liée à la fiche séance.</small>
                  </div>
                ) : (
                  <select value={fTeam} onChange={(e) => { setFTeam(e.target.value); setFPlayers([]); }}>
                    <option value="">Aucune</option>
                    {teams.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
                  </select>
                )}
              </div>

              <div className="cal-fld">
                <label>Thème</label>
                <input type="text" value={fTitle} onChange={(e) => setFTitle(e.target.value)} placeholder="Ex : Défense" />
              </div>

              <div className="cal-fld">
                <label>Adversaire</label>
                <input type="text" value={fOpp} onChange={(e) => setFOpp(e.target.value)} placeholder="Ex : Massy" />
              </div>

              <div className="cal-fld">
                <label>Lieu (salle / gymnase)</label>
                <input type="text" value={fLoc} onChange={(e) => setFLoc(e.target.value)} placeholder="Ex : Gymnase municipal" />
              </div>

              <div className="cal-fld">
                <label>Joueurs assignés</label>
                {selectedTeam ? (
                  selectedTeam.players.length ? (
                    <div className="cal-players">
                      {selectedTeam.players.map((player) => (
                        <button
                          type="button"
                          key={player.id}
                          className={
                            "cal-player-card" +
                            (fPlayers.includes(player.id) ? " on" : "")
                          }
                          onClick={() => togglePlayer(player.id)}
                        >
                          <span className="cal-player-avatar">
                            {player.avatarUrl ? (
                              <img
                                src={player.avatarUrl}
                                alt={`${player.firstName} ${player.lastName || ""}`}
                              />
                            ) : (
                              <b>{player.firstName.slice(0, 1).toUpperCase()}</b>
                            )}
                          </span>
                          <span className="cal-player-info">
                            <strong>
                              {player.firstName} {player.lastName || ""}
                            </strong>
                            <small>
                              {player.position || "Poste non défini"}
                              {player.number ? ` · #${player.number}` : ""}
                            </small>
                          </span>
                          <span className="cal-player-check">
                            {fPlayers.includes(player.id) ? "✓" : "+"}
                          </span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <span className="cal-pempty">Cette équipe n'a pas encore de joueurs.</span>
                  )
                ) : (
                  <span className="cal-pempty">Sélectionne une équipe pour assigner des joueurs.</span>
                )}
              </div>

              <div className="cal-fld">
                <label>Notes</label>
                <textarea value={fNotes} onChange={(e) => setFNotes(e.target.value)} placeholder="Infos complémentaires…" />
              </div>
              <div className="cal-fld">
                <label>Fiche séance</label>
                {editingId && events.find((event) => event.id === editingId)?.sessionId ? (
                  <button
                    type="button"
                    className="cal-open-session"
                    onClick={() => {
                      if (editingId) void consultSessionPdf(editingId);
                    }}
                  >
                    Consulter la fiche séance
                  </button>
                ) : (
                  <div className="cal-attach">
                    <label className="cal-attach-btn">📎 Ajouter une pièce jointe<input type="file" accept=".pdf,image/*,.doc,.docx,.txt" hidden onChange={(e) => onAttach(e.target.files?.[0])} /></label>
                    {fAttach && <span className="cal-attach-name"><span className="cal-attach-fn">{fAttach.name}</span><button type="button" className="cal-attach-act" onClick={() => setPreview(fAttach)}>Consulter</button><button type="button" className="cal-attach-rm" onClick={() => setFAttach(null)}>Retirer ✕</button></span>}
                  </div>
                )}
              </div>
            </div>

            <div className="cal-modal-actions">
              {editingId && <button type="button" className="cal-del" onClick={deleteEvent}>Supprimer</button>}
              <span className="spacer" />
              <button type="button" className="btn btn-outline" onClick={() => setOpen(false)}>Annuler</button>
              <button type="button" className="btn btn-black" onClick={saveEvent}>💾 Sauvegarder</button>
            </div>
          </div>
        </div>
      )}

      {/* Modale de prévisualisation de la pièce jointe */}
      {preview && (
        <div className="cal-overlay cal-overlay-top" onClick={() => setPreview(null)}>
          <div className="cal-preview" onClick={(e) => e.stopPropagation()}>
            <div className="cal-modal-head">
              <b>{preview.name}</b>
              <button className="cal-x" onClick={() => setPreview(null)} aria-label="Fermer">✕</button>
            </div>
            <div className="cal-preview-body">
              {isImage(preview) ? (
                <img src={preview.dataUrl} alt={preview.name} />
              ) : isPdf(preview) ? (
                <iframe src={preview.dataUrl} title={preview.name} />
              ) : (
                <div className="cal-preview-other">
                  <p>Aperçu non disponible pour ce type de fichier.</p>
                  <a className="btn btn-outline btn-small" href={preview.dataUrl} download={preview.name}>Ouvrir le fichier</a>
                </div>
              )}
            </div>
            <div className="cal-modal-actions">
              <span className="spacer" />
              <button type="button" className="btn btn-outline" onClick={() => setPreview(null)}>Fermer</button>
              <button type="button" className="btn btn-black" onClick={() => printAttachment(preview)}>🖨 Imprimer</button>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .mb-cal{
          --bordeaux:#6B1A2C; --or:#D4A24C; --or-l:#E8C078;
          --noir:#0F0F12; --blanc:#FFFFFF;
          --gris-bg:#F5F5F5; --gris-med:#C8C8C8; --gris-text:#6B6B6B; --rouge:#E63946;
          --varsity:'Alfa Slab One',serif;
          color:var(--noir);
        }
        /* En-tête (reprend les styles inline du HTML) */
        .cal-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:.85rem;flex-wrap:wrap;gap:.5rem}
        .cal-title{font-family:var(--varsity);letter-spacing:.05em;margin:0}
        .cal-actions{display:flex;gap:.4rem}

        /* Boutons (repris à l'identique de la référence) */
        .btn{display:inline-flex;align-items:center;justify-content:center;gap:.45rem;padding:.6rem 1.25rem;border-radius:999px;font-weight:500;font-size:.92rem;transition:.15s;cursor:pointer;border:none;background:none;color:inherit;font-family:inherit}
        .btn-small{padding:.35rem .85rem;font-size:.82rem}
        .btn-black{background:var(--noir);color:var(--blanc)}
        .btn-black:hover{background:var(--bordeaux);transform:translateY(-1px)}
        .btn-outline{background:transparent;border:1.5px solid var(--noir);color:var(--noir)}
        .btn-outline:hover{background:var(--noir);color:var(--blanc)}
        .btn-red{background:var(--rouge);color:var(--blanc)}
        .btn-red:hover{background:#B91C2C}

        /* Grille calendrier — valeurs EXACTES du HTML de référence */
        .cal-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:1px;background:var(--gris-med);border:1px solid var(--gris-med);border-radius:6px;overflow:hidden}
        .cal-h{background:var(--noir);color:var(--blanc);padding:.45rem;text-align:center;font-weight:700;font-size:.8rem}
        .cal-d{background:var(--blanc);min-height:72px;padding:.35rem;cursor:pointer;font-size:.82rem;position:relative}
        .cal-d:hover{background:var(--gris-bg)}
        .cal-d.empty{background:var(--gris-bg);cursor:default;opacity:.5}
        .cal-d.today{background:rgba(212,162,76,.15)}
        .cal-d .dn{font-weight:700}
        .cal-d .ev{font-size:.68rem;font-weight:600;padding:1px 4px;border-radius:3px;margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:pointer}

        /* Légende (styles inline d'origine) */
        .cal-legend{display:flex;gap:.6rem;flex-wrap:wrap;margin-top:.85rem;padding:.6rem .85rem;background:#FAF7F0;border-radius:6px;font-size:.72rem;align-items:center}
        .leg-title{font-weight:600;color:var(--bordeaux)}
        .leg-item{display:inline-flex;align-items:center;gap:.25rem}
        .leg-sw{width:14px;height:14px;border-radius:3px;display:inline-block}

        /* Modale enrichie */
        .cal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;z-index:1000;padding:1rem}
        .cal-overlay-top{z-index:1100;background:rgba(0,0,0,.65)}
        .cal-modal{width:520px;max-width:96vw;max-height:90vh;overflow-y:auto;background:#fff;border-radius:16px;box-shadow:0 24px 60px rgba(0,0,0,.4)}
        .cal-modal-head{display:flex;align-items:center;justify-content:space-between;padding:1.1rem 1.4rem;border-bottom:1px solid var(--gris-med)}
        .cal-modal-head b{font-family:var(--varsity);font-size:1.25rem;letter-spacing:.03em;color:var(--noir)}
        .cal-x{cursor:pointer;color:var(--gris-text);font-size:1.2rem;line-height:1;border:none;background:none;padding:.2rem}
        .cal-x:hover{color:var(--noir)}

        .cal-body{padding:1rem 1.4rem;display:flex;flex-direction:column;gap:.9rem}
        .cal-fld{display:flex;flex-direction:column;gap:.35rem}
        .cal-fld label{font-size:.72rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--gris-text)}
        .cal-fld .req{color:var(--rouge)}
        .cal-fld input,.cal-fld select,.cal-fld textarea{padding:.6rem .8rem;border:1px solid var(--gris-med);border-radius:10px;font-size:.9rem;font-family:inherit;background:var(--gris-bg);color:var(--noir);transition:.15s}
        .cal-fld input:focus,.cal-fld select:focus,.cal-fld textarea:focus{outline:none;border-color:var(--or);background:#fff;box-shadow:0 0 0 3px rgba(212,162,76,.18)}
        .cal-fld textarea{resize:vertical;min-height:72px}
        .cal-row2{display:grid;grid-template-columns:1fr 1fr;gap:.8rem}
        .cal-help{font-size:.74rem;color:var(--gris-text);line-height:1.4;margin:.1rem 0 0}

        .cal-readonly-team{padding:.8rem 1rem;border:1px solid #eaded7;border-radius:12px;background:#f8f5f3}.cal-readonly-team strong,.cal-readonly-team small{display:block}.cal-readonly-team strong{color:var(--bordeaux)}.cal-readonly-team small{margin-top:.25rem;color:var(--gris-text);font-size:.75rem}.cal-open-session{width:100%;padding:.9rem 1rem;border:0;border-radius:12px;background:var(--bordeaux);color:#fff;font-weight:950;cursor:pointer}
        .cal-players{display:flex;flex-wrap:wrap;gap:.4rem}
        .cal-pchip{display:inline-flex;align-items:center;gap:.2rem;padding:.4rem .75rem;border:1.5px solid var(--gris-med);border-radius:999px;font-size:.8rem;font-weight:600;cursor:pointer;background:#fff;color:var(--noir);transition:.13s}
        .cal-pchip:hover{border-color:var(--noir)}
        .cal-pchip.on{background:var(--bordeaux);border-color:var(--bordeaux);color:#fff}
        .cal-pempty{font-size:.78rem;color:var(--gris-text)}

        .cal-attach{display:flex;align-items:center;gap:.6rem;flex-wrap:wrap}
        .cal-attach-btn{display:inline-flex;align-items:center;gap:.4rem;padding:.55rem .9rem;border:1.5px dashed var(--gris-med);border-radius:10px;font-size:.82rem;font-weight:600;cursor:pointer;color:var(--noir);background:#fff;transition:.13s}
        .cal-attach-btn:hover{border-color:var(--or)}
        .cal-attach-name{display:inline-flex;align-items:center;gap:.5rem;font-size:.8rem;color:var(--noir);background:var(--gris-bg);padding:.4rem .6rem;border-radius:8px;max-width:100%}
        .cal-attach-fn{max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .cal-attach-act{border:1.5px solid var(--noir);background:#fff;color:var(--noir);border-radius:999px;padding:.25rem .7rem;font-size:.74rem;font-weight:700;cursor:pointer;transition:.13s}
        .cal-attach-act:hover{background:var(--noir);color:#fff}
        .cal-attach-rm{border:none;background:none;color:var(--rouge);font-size:.74rem;font-weight:700;cursor:pointer;white-space:nowrap}
        .cal-attach-rm:hover{text-decoration:underline}

        .cal-modal-actions{display:flex;align-items:center;gap:.6rem;padding:1rem 1.4rem 1.4rem}
        .cal-modal-actions .spacer{flex:1}
        .cal-del{border:none;background:none;color:var(--rouge);font-weight:600;font-size:.82rem;cursor:pointer;padding:.3rem .2rem}
        .cal-del:hover{text-decoration:underline}

        /* Modale de prévisualisation */
        .cal-preview{width:760px;max-width:96vw;max-height:92vh;display:flex;flex-direction:column;background:#fff;border-radius:16px;box-shadow:0 24px 60px rgba(0,0,0,.45);overflow:hidden}
        .cal-preview-body{flex:1;min-height:0;overflow:auto;background:#f2f2f2;display:flex;align-items:center;justify-content:center;padding:1rem}
        .cal-preview-body img{max-width:100%;max-height:74vh;object-fit:contain;border-radius:6px;box-shadow:0 4px 16px rgba(0,0,0,.2)}
        .cal-preview-body iframe{width:100%;height:74vh;border:0;background:#fff;border-radius:6px}
        .cal-preview-other{display:flex;flex-direction:column;align-items:center;gap:.85rem;color:var(--gris-text);font-size:.9rem;text-align:center}
        .cal-players{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr));gap:.6rem!important}
        .cal-player-card{display:grid;grid-template-columns:40px 1fr 28px;align-items:center;gap:.65rem;width:100%;padding:.65rem;border:1px solid #e8ded8;border-radius:14px;background:#fff;text-align:left;cursor:pointer;transition:.18s ease}
        .cal-player-card:hover{transform:translateY(-2px);box-shadow:0 10px 24px rgba(107,26,44,.09)}
        .cal-player-card.on{border-color:var(--or);background:#fff8e9;box-shadow:0 0 0 2px rgba(212,162,76,.13)}
        .cal-player-avatar{width:40px;height:40px;border-radius:12px;overflow:hidden;display:grid;place-items:center;background:var(--noir);color:var(--or)}
        .cal-player-avatar img{width:100%;height:100%;object-fit:cover}
        .cal-player-info strong,.cal-player-info small{display:block}
        .cal-player-info strong{font-size:.84rem;color:var(--noir)}
        .cal-player-info small{margin-top:.15rem;color:var(--gris-text);font-size:.7rem}
        .cal-player-check{width:26px;height:26px;border-radius:9px;display:grid;place-items:center;background:#f2ece8;color:var(--bordeaux);font-weight:950}
        .cal-player-card.on .cal-player-check{background:var(--bordeaux);color:#fff}
        .cal-session-overlay{z-index:10000}
        .cal-session-preview{width:min(1180px,calc(100vw - 36px));height:min(860px,calc(100vh - 36px));display:flex;flex-direction:column;overflow:hidden;border-radius:22px;background:#fff;box-shadow:0 30px 90px rgba(0,0,0,.35)}
        .cal-session-preview .cal-modal-head span{display:block;color:var(--or);font-size:.68rem;font-weight:950;letter-spacing:.12em}
        .cal-session-preview iframe{width:100%;flex:1;border:0;background:#eef1f5}

        @media (max-width:600px){
          .cal-d{min-height:60px;padding:.25rem}
          .cal-d .ev{font-size:.6rem}
          .cal-h{font-size:.72rem;padding:.35rem}
          .cal-row2{grid-template-columns:1fr}
          .cal-preview-body iframe{height:60vh}
        }
      `}</style>
    </div>
  );
}